# team4edids
Group project of software engineering.

- [X] Save file
- [ ] Classe Loadings
- [X] Classe Player
- [ ] Classe Game
- [ ] Salvataggio partita
- [ ] Stampa a terminale dei messaggi e mappa
- [ ] Applicazione avviabile
- [ ] Unit testing per tutte le classi
- [ ] Creazione avviabile con maven
- [ ] Controllare e pulire codice
- [ ] Commentare il codice
- [ ] Scrivere messaggi e descrizioni di tutti mob e oggetti
- [ ] Bilanciare il gioco
- [ ] Rinominare le classi
- [ ] Controllare accessi dei metodi
- [ ] Controllare l'array di passaggi nelle room
- [X] Implementare to string
- [ ] Implementare lettura multipli salvataggi 
- [ ] Dire messaggio quando il trader ti da un item
- [X] Lo spirito dello shamano non viene aggiunto alla stanza
- [X] La mummia droppa un oggetto illegale
- [X] Ammazzare boss con oggetto giusto
- [ ] Cambiare descrizioni items
- [ ] sistemare scritta you won
