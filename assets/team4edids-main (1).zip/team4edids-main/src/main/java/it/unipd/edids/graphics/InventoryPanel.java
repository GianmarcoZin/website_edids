package it.unipd.edids.graphics;

import javax.swing.*;
import java.awt.*;
import java.util.Stack;

public class InventoryPanel extends JLayeredPane {
    public static final int X = CombatPanel.X + CombatPanel.WIDTH + 20;
    public static final int Y = 25;
    public static final int PANEL_WIDTH = Frame.FRAME_WIDTH - X - InventoryPanel.BORDER_SIZE * 2-40;
    public static final int PANEL_HEIGHT = CombatPanel.HEIGHT;
    public static final int BORDER_SIZE = 0;
    public static final int COLUMNS = 2;
    public static final int ITEM_WIDTH = ItemLabel.LABEL_WIDTH;
    public static final int ITEM_HEIGHT = ItemLabel.LABEL_HEIGHT;
    private final Stack<InventoryItemLabel> inventoryItems;

    public InventoryPanel() {
        this.inventoryItems = new Stack<>();
        setBounds(X, Y, PANEL_WIDTH, PANEL_HEIGHT);
        setOpaque(false);
        // setBackground(Color.decode("#B9561E"));
        //setBorder(BorderFactory.createMatteBorder(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, Color.decode("#E1DACE")));
    }

    public void removeAllItems(){
        while (!inventoryItems.isEmpty()){
            remove(inventoryItems.pop());
        }
    }

    public void addItem(int itemId) {
        InventoryItemLabel temp = new InventoryItemLabel(itemId, new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/inventory/" + itemId + ".png")), 1);
        if (inventoryItems.contains(temp)) {
            inventoryItems.get(inventoryItems.indexOf(temp)).setQuantity(inventoryItems.get(inventoryItems.indexOf(temp)).getQuantity() + 1);
        } else {
            temp.setLocation((inventoryItems.size() % COLUMNS) * ITEM_WIDTH, (inventoryItems.size() / COLUMNS) * ITEM_HEIGHT - InventoryItemLabel.PADDING);
            inventoryItems.push(temp);
            add(temp);
        }
        //paintInventory();
    }

    public void removeItem(int itemId) {
        InventoryItemLabel temp = new InventoryItemLabel(itemId, null, 0);
        if (inventoryItems.contains(temp)) {
            InventoryItemLabel itemInList = inventoryItems.get(inventoryItems.indexOf(temp));
            itemInList.setQuantity(itemInList.getQuantity() - 1);
            if (itemInList.getQuantity() == 0) {
                if (inventoryItems.size() >= 2 && !itemInList.equals(inventoryItems.peek())) {
                    inventoryItems.peek().setLocation(itemInList.getX(), itemInList.getY());
                    replaceInStack(itemInList, inventoryItems.peek());
                }
                inventoryItems.pop();
                remove(itemInList);
            }
        }
        //paintInventory();
    }

    private void replaceInStack(InventoryItemLabel toBeReplaced, InventoryItemLabel replacement) {
        Stack<InventoryItemLabel> tempStack = new Stack<>();
        while (!inventoryItems.peek().equals(toBeReplaced)) {
            tempStack.push(inventoryItems.pop());
        }
        inventoryItems.pop();
        inventoryItems.push(replacement);
        while (!tempStack.isEmpty()) {
            inventoryItems.push(tempStack.pop());
        }
    }

    public void equipItem(int itemId) {
        for (int i = 0; i < inventoryItems.size(); i++) {
            if (inventoryItems.get(i).getId() == itemId) {
                inventoryItems.get(i).setEquipped(true);
            } else {
                inventoryItems.get(i).setEquipped(false);
            }
        }
        //paintInventory();
    }
}
