package it.unipd.edids.items;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "pickableItem")
public class PickableItem extends Item {
    private int weight;

    public PickableItem(int id, String name, String description, int weight) {
        super(id, name, description);
        this.weight = weight;
    }

    public PickableItem() {
        super(0, null, null);
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return super.toString() + "->" + "PickableItem{" +
                "weight=" + weight +
                '}';
    }
}
