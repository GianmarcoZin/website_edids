package it.unipd.edids.jakarta.wrappers;

import it.unipd.edids.items.WeaponItem;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

@XmlRootElement(name = "weaponItems")
@XmlAccessorType(XmlAccessType.FIELD)
public class WeaponItemList {
    @XmlElement(name = "weaponItem")
    private List<WeaponItem> weaponItemList;

    /**
     * Default constructor for the WeaponItemList class
     */
    public WeaponItemList() {
    }

    /**
     * Constructor for the WeaponItemList class
     *
     * @param weaponItemList list of weapon items
     */
    public WeaponItemList(List<WeaponItem> weaponItemList) {
        this.weaponItemList = weaponItemList;
    }

    /**
     * Getter for the list of weapon items
     *
     * @return list of weapon items
     */
    public List<WeaponItem> getWeaponItemList() {
        return weaponItemList;
    }

    /**
     * Setter for the list of weapon items
     *
     * @param weaponItemList list of weapon items
     */
    public void setWeaponItemList(List<WeaponItem> weaponItemList) {
        this.weaponItemList = weaponItemList;
    }
}
