package it.unipd.edids.jakarta.wrappers;

import it.unipd.edids.entities.Trader;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

/**
 * Wrapper utility class for the list of traders
 */
@XmlRootElement(name = "traders")
@XmlAccessorType(XmlAccessType.FIELD)
public class TraderList {
    @XmlElement(name = "trader")
    private List<Trader> traderList;

    /**
     * Default constructor for the TraderList class
     */
    public TraderList() {
    }

    /**
     * Constructor for the TraderList class
     *
     * @param traderList list of traders
     */
    public TraderList(List<Trader> traderList) {
        this.traderList = traderList;
    }

    /**
     * Getter for the list of traders
     *
     * @return list of traders
     */
    public List<Trader> getTraderList() {
        return traderList;
    }

    /**
     * Setter for the list of traders
     *
     * @param traderList list of traders
     */
    public void setTraderList(List<Trader> traderList) {
        this.traderList = traderList;
    }
}
