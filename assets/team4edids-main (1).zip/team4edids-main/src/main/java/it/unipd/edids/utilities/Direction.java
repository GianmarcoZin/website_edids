package it.unipd.edids.utilities;

/**
 * Enumeration class for the directions
 */
public enum Direction {
    NORTH, EAST, SOUTH, WEST
}
