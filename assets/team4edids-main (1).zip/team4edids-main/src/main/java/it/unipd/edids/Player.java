package it.unipd.edids;

import it.unipd.edids.items.ConsumableItem;
import it.unipd.edids.items.NonPickableItem;
import it.unipd.edids.utilities.ItemPair;

import java.util.ArrayList;

public class Player {
    private ArrayList<ItemPair> inventory;
    private int hp;
    private int score;
    private int bossesDefeated;

    private int inventoryWeight;
    private int equippedWeaponID;
    public final int MAX_WEIGHT = 10;
    public final int MAX_HEALTH = 100;
    public ArrayList<Integer> effectList;

    public Player(ArrayList<ItemPair> inventory, int hp, int equippedWeaponID, int score, int bossesDefeated, ArrayList<Integer> effectList) {
        this.inventory = inventory;
        this.hp = hp;
        this.score = score;
        this.equippedWeaponID = equippedWeaponID;
        this.inventoryWeight = 0;
        this.bossesDefeated = bossesDefeated;
        this.effectList = effectList;
    }

    public Player() {
        this.inventory = null;
        this.hp = 0;
        this.score = 0;
        this.equippedWeaponID = -1;
        this.inventoryWeight = 0;
    }

    public void addHp(int addedHp) {
        hp += addedHp;
    }

    public void setHP(int hp) {
        this.hp = hp;
    }// getHP

    public int getHP() {
        return hp;
    }// getHP

    public void setInventory(ArrayList<ItemPair> inventory) {
        this.inventory = inventory;
    }// setInventory

    public ArrayList<ItemPair> getInventory() {
        return inventory;
    }

    public ItemPair drop(int id, int weight) throws Exception {
        for (int i = 0; i < inventory.size(); i++)
            if (inventory.get(i).getId() == id) {
                inventoryWeight -= weight;
                if (inventory.get(i).getQuantity() > 1) {
                    inventory.get(i).setQuantity(inventory.get(i).getQuantity() - 1);
                    return new ItemPair(id, 1);
                } else {
                    if (equippedWeaponID == id) equippedWeaponID = -1;
                    return inventory.remove(i);
                }
            }
        throw new Exception("Object not in inventory");
    }// drop

    public void add(ItemPair entry, int weight) throws Exception {
        if (inventoryWeight + weight > MAX_WEIGHT)
            throw new Exception("Inventory max weight exceeded");
        inventoryWeight += weight;
        for (int i = 0; i < inventory.size(); i++)
            if (inventory.get(i).getId() == entry.getId()) {
                inventory.get(i).setQuantity(inventory.get(i).getQuantity() + entry.getQuantity());
                return;
            }
        inventory.add(entry);
    }

    public int use(ConsumableItem item) throws Exception {
        if (item.getHp() == 0) {
            effectList.add(item.getId());
        }
        drop(item.getId(), item.getWeight());
        hp += item.getHp();
        if (hp > MAX_HEALTH) {
            hp = MAX_HEALTH;
        }
        return item.getHp();
    }

    public int use(NonPickableItem item) {
        hp += item.getHp();
        if (hp > MAX_HEALTH) {
            hp = MAX_HEALTH;
        } else if (hp < 0) {
            hp = 0;
        }
        return item.getHp();
    }

    public ArrayList<Integer> getEffectList() {
        return effectList;
    }

    public void setEffectList(ArrayList<Integer> effectList) {
        this.effectList = effectList;
    }

    public void setEquippedWeaponID(int equippedWeaponID) throws Exception {
        if (!hasItem(equippedWeaponID))
            throw new Exception("Item not in inventory");
        this.equippedWeaponID = equippedWeaponID;
    }

    public int getEquippedID() {
        return equippedWeaponID;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setInventoryWeight(int inventoryWeight) {
        this.inventoryWeight = inventoryWeight;
    }

    public int getInventoryWeight() {
        return inventoryWeight;
    }

    public int getBossesDefeated() {
        return bossesDefeated;
    }

    public void setBossesDefeated(int bossesDefeated) {
        this.bossesDefeated = bossesDefeated;
    }

    public void incrementBossesDefeated(){
        bossesDefeated++;
    }


    public boolean hasItem(int itemID) {
        if (inventory.indexOf(new ItemPair(itemID, 0)) == -1)
            return false;
        else
            return true;
    }

    @Override
    public String toString() {
        return "Player{" +
                "inventory=" + inventory +
                ", hp=" + hp +
                ", score=" + score +
                ", inventoryWeight=" + inventoryWeight +
                ", equippedWeaponID=" + equippedWeaponID +
                ", MAX_WEIGHT=" + MAX_WEIGHT +
                '}';
    }
}
