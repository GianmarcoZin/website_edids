package it.unipd.edids.entities;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "monster")
public class Monster extends Entity {
    private int damage;
    private int maxHp;
    private int hp;
    private int effectId;

    public Monster(int id, String name, int dropID, int damage, int hp, int maxHp, int effectId) {
        super(id, name, dropID);
        this.damage = damage;
        this.hp = hp;
        this.maxHp = maxHp;
        this.effectId = effectId;
    }

    public Monster() {
        super(-1, null, -1);
        this.damage = 0;
        this.hp = 0;
        this.maxHp = 0;
    }

    @Override
    public int dropItem() {
        return getDropID();
    }

    public int getHp() {
        return hp;
    }

    public int attack() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getDamage() {
        return damage;
    }

    public int getEffectId() {
        return effectId;
    }

    public void setEffectId(int effectId) {
        this.effectId = effectId;
    }

    public boolean getIsBoss() {
        return effectId != -1;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }

    @Override
    public String toString() {
        return super.toString() + "->" + "Monster{" +
                "damage=" + damage +
                ", hp=" + hp +
                '}';
    }
}
