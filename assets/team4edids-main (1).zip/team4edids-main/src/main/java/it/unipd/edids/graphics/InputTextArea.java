package it.unipd.edids.graphics;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class InputTextArea extends JTextArea{
    public static final int BOTTOM_PADDING = 65;
    public static final int X = 25;
    public static final int HEIGHT = 80;
    public static final int INNER_PADDING = 18;
    public static final int WIDTH = Frame.FRAME_WIDTH - 2 * X - INNER_PADDING;
    public static final int Y = Frame.FRAME_HEIGHT - BOTTOM_PADDING - HEIGHT;
    public static final String BORDER_COLOR = Frame.BORDER_COLOR;
    public static final String BACKGROUND_COLOR = Frame.BACKGROUND_COLOR;
    public static final int BORDER_SIZE = 2;

    public InputTextArea() {
        this.setBounds(X, Y, WIDTH, HEIGHT);
        this.setBackground(Color.decode(BACKGROUND_COLOR));
        this.setOpaque(true);
        this.setFont(Frame.FONT);
        this.setForeground(Color.decode(BORDER_COLOR));
        this.setBorder(new CompoundBorder(
                BorderFactory.createMatteBorder(0,BORDER_SIZE,BORDER_SIZE,BORDER_SIZE,Color.decode(BORDER_COLOR)),
                BorderFactory.createEmptyBorder(INNER_PADDING, INNER_PADDING, INNER_PADDING, INNER_PADDING)));
        this.setCaretColor(Color.decode(BORDER_COLOR));
    }
}
