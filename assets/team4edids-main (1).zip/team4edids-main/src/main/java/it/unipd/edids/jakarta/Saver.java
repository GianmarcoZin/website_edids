package it.unipd.edids.jakarta;

import it.unipd.edids.Game;
import it.unipd.edids.Map;
import it.unipd.edids.amazon.AWSS3Handler;
import it.unipd.edids.entities.Entity;
import it.unipd.edids.entities.Monster;
import it.unipd.edids.Room;
import it.unipd.edids.entities.Trader;
import it.unipd.edids.utilities.ItemPair;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.ArrayList;

/**
 * Class for saving the game state to an XML file
 */
public class Saver {
    /**
     * Saves the game state to an XML file
     *
     * @param game      the game to save
     * @param fileName  the name of the file to save
     * @param s3Handler the handler for the S3 bucket
     * @return the name of the file saved
     * @throws ParserConfigurationException if the parser configuration is invalid
     */
    public static String saveGame(Game game, String fileName, AWSS3Handler s3Handler) throws ParserConfigurationException {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        // creating root elements to save in the XML file
        Document doc = docBuilder.newDocument();
        Element rootElement = doc.createElement("save");
        doc.appendChild(rootElement);

        // adding all the elements to the root element
        rootElement.appendChild(saveRooms(doc, game.getGameMap()));
        rootElement.appendChild(savePlayer(doc, game));

        try {
            // write the content into XML file
            File saveFile = File.createTempFile(fileName, ".xml");
            FileOutputStream output = new FileOutputStream(saveFile);
            writeXml(doc, output);
            // upload to S3
            return s3Handler.uploadObject(fileName, saveFile);
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    /**
     * Deletes a save from the S3 bucket
     *
     * @param fileName  the name of the file to delete
     * @param s3Handler the handler for the S3 bucket
     * @return a message indicating the result of the operation
     */
    public static String deleteSave(String fileName, AWSS3Handler s3Handler) {
        return s3Handler.deleteObject(fileName);
    }

    /**
     * Checks if a save with the given name already exists in the S3 bucket
     *
     * @param name      the name of the save to check
     * @param s3Handler the handler for the S3 bucket
     * @return true if the save already exists, false otherwise
     */
    public static boolean alreadyExistingSaveName(String name, AWSS3Handler s3Handler) {
        return s3Handler.getObjectList().contains(name);
    }

    /**
     * Saves the player state to an XML element
     *
     * @param doc  the document for creating the element
     * @param game the game to save the player from
     * @return the player element
     */
    private static Element savePlayer(Document doc, Game game) {
        Element player = doc.createElement("player");
        Element playerPosition = doc.createElement("playerPosition");
        Element hp = doc.createElement("hp");
        Element score = doc.createElement("score");
        Element bossesDefeated = doc.createElement("bossesDefeated");
        Element equippedWeaponID = doc.createElement("equippedWeaponID");

        // set the values of the elements
        playerPosition.setTextContent(Integer.toString(game.getPlayerPosition()));
        hp.setTextContent(Integer.toString(game.getPlayer().getHP()));
        score.setTextContent(Integer.toString(game.getPlayer().getScore()));
        bossesDefeated.setTextContent(Integer.toString(game.getPlayer().getBossesDefeated()));
        equippedWeaponID.setTextContent(Integer.toString(game.getPlayer().getEquippedID()));
        Element inventory = getInventory(doc, game.getPlayer().getInventory());
        Element effects = getEffects(doc, game.getPlayer().getEffectList());

        // append the elements to the player element
        player.appendChild(playerPosition);
        player.appendChild(hp);
        player.appendChild(score);
        player.appendChild(bossesDefeated);
        player.appendChild(equippedWeaponID);
        player.appendChild(inventory);
        player.appendChild(effects);

        return player;
    }

    /**
     * Saves the effects of the player to an XML element
     *
     * @param doc        the document for creating the element
     * @param effectList the list of effects to save
     * @return the effects element
     */
    private static Element getEffects(Document doc, ArrayList<Integer> effectList) {
        Element effects = doc.createElement("effects");
        for (Integer integer : effectList) {
            Element element = doc.createElement("value");
            element.setTextContent(Integer.toString(integer));
            effects.appendChild(element);
        }
        return effects;
    }

    /**
     * Saves the inventory of the player to an XML element
     *
     * @param doc      the document for creating the element
     * @param itemList the list of items to save
     * @return the inventory element
     */
    private static Element getInventory(Document doc, ArrayList<ItemPair> itemList) {
        Element items = doc.createElement("inventory");
        for (ItemPair itemPair : itemList) {
            Element item = doc.createElement("item");
            Element id = doc.createElement("id");
            Element quantity = doc.createElement("quantity");
            id.setTextContent(Integer.toString(itemPair.getId()));
            quantity.setTextContent(Integer.toString(itemPair.getQuantity()));
            item.appendChild(id);
            item.appendChild(quantity);
            items.appendChild(item);
        }
        return items;
    }

    /**
     * Saves the rooms of the game to an XML element
     *
     * @param doc     the document for creating the element
     * @param gameMap the map of the game to save
     * @return the rooms element
     */
    private static Element saveRooms(Document doc, Map gameMap) {
        Element rooms = doc.createElement("rooms");

        for (int i = 0; i < gameMap.getSize(); i++) {
            rooms.appendChild(getRoom(doc, gameMap.getRoom(i)));
        }

        return rooms;
    }

    /**
     * Saves a room to an XML element
     *
     * @param doc      the document for creating the element
     * @param roomItem the room to save
     * @return the room element
     */
    private static Element getRoom(Document doc, Room roomItem) {
        Element room = doc.createElement("room");
        Element id = doc.createElement("id");
        Element isDiscovered = doc.createElement("isDiscovered");

        id.setTextContent(Integer.toString(roomItem.getId()));
        isDiscovered.setTextContent(Boolean.toString(roomItem.isDiscovered()));
        room.appendChild(id);
        room.appendChild(isDiscovered);
        room.appendChild(getItems(doc, roomItem.getItems()));
        room.appendChild(getRoomEntities(doc, roomItem.getEntities()));

        return room;
    }

    /**
     * Saves the entities of a room to an XML element
     *
     * @param doc          the document for creating the element
     * @param roomEntities the list of entities to save
     * @return the entities element
     */
    private static Element getRoomEntities(Document doc, ArrayList<Entity> roomEntities) {
        Element roomEntitiesDocument = doc.createElement("entities");

        for (int i = 0; i < roomEntities.size(); i++) {
            Element entity = doc.createElement("entity");
            Element id = doc.createElement("id");
            id.setTextContent(Integer.toString(roomEntities.get(i).getId()));
            entity.appendChild(id);
            if (roomEntities.get(i) instanceof Monster) {
                Element hp = doc.createElement("hp");
                hp.setTextContent(Integer.toString(((Monster) roomEntities.get(i)).getHp()));
                entity.appendChild(hp);
            } else {
                Element state = doc.createElement("state");
                state.setTextContent(Integer.toString(((Trader) roomEntities.get(i)).getState().ordinal()));
                entity.appendChild(state);
            }
            roomEntitiesDocument.appendChild(entity);
        }

        return roomEntitiesDocument;
    }

    /**
     * Saves the items of a room to an XML element
     *
     * @param doc       the document for creating the element
     * @param roomItems the list of items to save
     * @return the items element
     */
    private static Element getItems(Document doc, ArrayList<ItemPair> roomItems) {
        Element roomItemsDocument = doc.createElement("items");

        for (ItemPair roomItem : roomItems) {
            Element item = doc.createElement("item");
            Element id = doc.createElement("id");
            Element quantity = doc.createElement("quantity");

            id.setTextContent(Integer.toString(roomItem.getId()));
            quantity.setTextContent(Integer.toString(roomItem.getQuantity()));

            item.appendChild(id);
            item.appendChild(quantity);

            roomItemsDocument.appendChild(item);
        }

        return roomItemsDocument;
    }

    /**
     * Writes the XML document to an output stream
     *
     * @param doc    the document to write
     * @param output the output stream to write to
     * @throws TransformerException if the transformation fails
     */
    private static void writeXml(Document doc, OutputStream output) throws TransformerException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(output);

        transformer.transform(source, result);
    }

}
