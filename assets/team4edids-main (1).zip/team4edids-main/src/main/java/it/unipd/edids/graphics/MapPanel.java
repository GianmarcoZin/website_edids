package it.unipd.edids.graphics;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public class MapPanel extends JLayeredPane {
    public static final int NUMBER_OF_ROOMS = 16;
    public static final int BORDER_SIZE = 2;
    public static final int PANEL_WIDTH = Frame.FRAME_WIDTH / 5;
    public static final int ROOM_WIDTH = PANEL_WIDTH / 4;
    public static final int PLAYER_WIDTH = PANEL_WIDTH / 12;
    public static final int PADDING = 25;
    JLabel[] rooms;
    JLabel player;
    private int playerPosition;

    public MapPanel(){
        this.rooms = new JLabel[NUMBER_OF_ROOMS];
        ImageIcon[] images = new ImageIcon[NUMBER_OF_ROOMS];
        this.setLayout(null);
        setBounds(PADDING, PADDING,PANEL_WIDTH,PANEL_WIDTH);
        setBackground(Color.decode("#24495B"));
        setOpaque(true);
        setBorder(BorderFactory.createMatteBorder(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, Color.decode("#E1DACE")));

        String[] mapElements = new String[]{
                "img/map/right_bottom.png",
                "img/map/left_right_bottom.png",
                "img/map/left_right.png",
                "img/map/left_bottom.png",
                "img/map/top_right_bottom.png",
                "img/map/top_left_right_bottom.png",
                "img/map/left_bottom.png",
                "img/map/top_bottom.png",
                "img/map/top.png",
                "img/map/top_bottom.png",
                "img/map/top_right_bottom.png",
                "img/map/top_left.png",
                "img/map/right.png",
                "img/map/left_top_right.png",
                "img/map/left_top_right.png",
                "img/map/left.png",
        };

        for (int i = 0; i < mapElements.length; i++) {
            images[i] = new ImageIcon(ClassLoader.getSystemClassLoader().getResource(mapElements[i]));
        }

        for (int i = 0; i < NUMBER_OF_ROOMS; i++) {
            images[i].setImage(images[i].getImage().getScaledInstance(PANEL_WIDTH / 4, PANEL_WIDTH / 4, Image.SCALE_SMOOTH));
        }
        for (int i = 0; i < NUMBER_OF_ROOMS; i++) {
            rooms[i] = new JLabel();
            rooms[i].setIcon(images[i]);
            rooms[i].setLayout(null);
            this.add(rooms[i]);
        }

        for (int i = 0; i < NUMBER_OF_ROOMS; i++) {
            if(i >= 0 && i <= 3){
                rooms[i].setBounds(ROOM_WIDTH * (i % 4),0,ROOM_WIDTH, ROOM_WIDTH);
            }else if(i >= 4 && i <= 7){
                rooms[i].setBounds(ROOM_WIDTH * (i % 4),ROOM_WIDTH,ROOM_WIDTH, ROOM_WIDTH);
            }else if(i >= 8 && i <= 11){
                rooms[i].setBounds(ROOM_WIDTH * (i % 4),(ROOM_WIDTH) * 2,ROOM_WIDTH, ROOM_WIDTH);
            }else{
                rooms[i].setBounds(ROOM_WIDTH * (i % 4),(ROOM_WIDTH) * 3,ROOM_WIDTH, ROOM_WIDTH);
            }
        }

        player = new JLabel();
        ImageIcon playerIcon = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/map/player_placeholder.png"));
        playerIcon.setImage(playerIcon.getImage().getScaledInstance(PLAYER_WIDTH, PLAYER_WIDTH, Image.SCALE_SMOOTH));
        //PANEL_WIDTH / 200 is a little margin to align better the placeholder
        player.setBounds((ROOM_WIDTH - PLAYER_WIDTH) / 2,(ROOM_WIDTH - PLAYER_WIDTH) / 2 - PANEL_WIDTH / 200, PLAYER_WIDTH, PLAYER_WIDTH);
        player.setIcon(playerIcon);
        this.playerPosition = 13;
        //rooms[playerPosition].add(player);
//        setPlayerPosition(playerPosition);
//        for (int i = 0; i < NUMBER_OF_ROOMS; i++) {
//            setVisible(i, false);
//        }
//        setVisible(playerPosition, true);
    }

    public void setVisible(int roomID, boolean visible){
        rooms[roomID].setVisible(visible);
    }

    public void setPlayerPosition(int roomID){
        rooms[playerPosition].remove(player);
        rooms[roomID].add(player);
        //this.repaint();
    }
}

