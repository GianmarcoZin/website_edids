package it.unipd.edids.graphics;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import java.awt.*;

public class InventoryItemLabel extends ItemLabel{

    public InventoryItemLabel(int id, ImageIcon image, int quantity) {
        super(id, image, quantity);
        setBorder(new CompoundBorder(
                BorderFactory.createMatteBorder(PADDING,PADDING,PADDING,PADDING,Color.decode(OUTSIDE_COLOR)),
                new CompoundBorder(
                        BorderFactory.createMatteBorder(THIN_BORDER, THIN_BORDER, THIN_BORDER, THIN_BORDER, Color.decode(BORDER_COLOR)),
                        BorderFactory.createEmptyBorder(PADDING,PADDING,PADDING,PADDING))));
        setBackground(Color.decode(BACKGROUND_COLOR));
        setOpaque(true);
        setForeground(Color.decode(BORDER_COLOR));
    }

    public void setEquipped(boolean equipped) {
        if (equipped) {
            setBorder(new CompoundBorder(
                    BorderFactory.createMatteBorder(PADDING,PADDING,PADDING,PADDING,Color.decode(OUTSIDE_COLOR)),
                    new CompoundBorder(
                            BorderFactory.createMatteBorder(THIN_BORDER, THIN_BORDER, THIN_BORDER, THIN_BORDER, Color.ORANGE),
                            BorderFactory.createEmptyBorder(PADDING,PADDING,PADDING,PADDING))));
        } else {
            setBorder(new CompoundBorder(
                    BorderFactory.createMatteBorder(PADDING,PADDING,PADDING,PADDING,Color.decode(OUTSIDE_COLOR)),
                    new CompoundBorder(
                            BorderFactory.createMatteBorder(THIN_BORDER, THIN_BORDER, THIN_BORDER, THIN_BORDER, Color.decode(BORDER_COLOR)),
                            BorderFactory.createEmptyBorder(PADDING,PADDING,PADDING,PADDING))));
        }
    }

    @Override
    public void setQuantity(int quantity) {
        super.setQuantity(quantity);
        if(getQuantity() <= 1){
            setText("X " + quantity);
        }
    }
}
