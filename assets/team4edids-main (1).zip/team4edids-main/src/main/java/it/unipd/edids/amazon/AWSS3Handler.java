package it.unipd.edids.amazon;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

/**
 * Class for handling the connection to the AWS S3 bucket
 */
public class AWSS3Handler {
    private static String accessKey;
    private static String secretKey;
    private static String bucketName;
    private AWSCredentials credentials = null;
    private AmazonS3 s3 = null;
    private boolean offlineMode;
    private final static String LIST_OBJECT_NAME = "list";

    /**
     * Constructor for the AWSS3Handler class
     */
    public AWSS3Handler() {
        offlineMode = false;
        bucketName = "";
        try {
            Properties auth = AWSPropertiesReader.readAuthProperties();

            accessKey = auth.getProperty("accessKey");
            secretKey = auth.getProperty("secretKey");
            bucketName = auth.getProperty("bucketName");

            credentials = new BasicAWSCredentials(accessKey, secretKey);

            s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.EU_NORTH_1).withCredentials(new AWSStaticCredentialsProvider(credentials)).build();
            s3.getBucketLocation(bucketName);
            return;

        } catch (IOException e) {
            offlineMode = true;
            System.out.println("WARNING: Could not read AWS credentials file.");
            System.out.println("Proceeding OFFLINE. You will NOT be able to save your progress.");
            accessKey = "";
            secretKey = "";
        } catch (Exception e) {
            offlineMode = true;
            System.out.println("WARNING: Could not connect to S3 bucket. Check your credentials or connect to a network.");
            System.out.println("Proceeding OFFLINE. You will NOT be able to save your progress.\n");
            accessKey = "";
            secretKey = "";
        }
    }

    /**
     * Uploads a file to the S3 bucket
     * @param key_name The name of the object in the bucket
     * @param file The file to upload
     * @return A string containing the result of the operation
     */
    public String uploadObject(String key_name, File file) {
        String s = "";
        if (offlineMode) {
            return "Offline mode: cannot upload file to S3";
        } else {
            s += "Uploading save to S3 bucket " + bucketName + "...\n";
            addElementToList(key_name);
            try {
                s3.putObject(bucketName, key_name, file);
            } catch (AmazonServiceException e) {
                s += e.getErrorMessage();
                return s;
            }

            return s;
        }
    }

    /**
     * Downloads an object from the S3 bucket
     * @param key_name The name of the object to download
     * @return A File object containing the downloaded object
     */
    public File donwloadObject(String key_name) {
        try {
            S3Object o = s3.getObject(bucketName, key_name);
            S3ObjectInputStream s3is = o.getObjectContent();

            File tempFile = File.createTempFile(key_name, ".xml");
            FileOutputStream fos = new FileOutputStream(tempFile);

            byte[] read_buf = new byte[1024];
            int read_len;
            while ((read_len = s3is.read(read_buf)) > 0) {
                fos.write(read_buf, 0, read_len);
            }

            s3is.close();

            return tempFile;
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
            System.exit(1);
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        } catch (IOException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        return null;
    }

    /**
     * Returns a list of all objects in the S3 bucket
     * @return An ArrayList of strings containing the names of the objects in the bucket
     */
    public ArrayList<String> getObjectList() {
        return readObjectListFromS3();
    }

    /**
     * Adds an element to the list of objects in the S3 bucket
     * @param name The name of the object to add
     */
    private void addElementToList(String name) {
        try {
            ArrayList<String> list = readObjectListFromS3();
            if (!list.contains(name)) {
                list.add(name);

                // Convert the ArrayList to a single string
                String data = String.join("\n", list);

                // Convert the string to a byte array
                byte[] bytes = data.getBytes();

                // Create an InputStream from the byte array
                InputStream is = new ByteArrayInputStream(bytes);

                // Create metadata and set content length
                ObjectMetadata meta = new ObjectMetadata();
                meta.setContentLength(bytes.length);

                // Upload the InputStream to S3
                s3.putObject(bucketName, LIST_OBJECT_NAME, is, meta);
            }
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
        }
    }

    /**
     * Removes an element from the list of objects in the S3 bucket
     * @param name The name of the object to remove
     */
    private void removeElementFromList(String name) {
        try {
            ArrayList<String> list = readObjectListFromS3();
            if (list.contains(name)) {
                list.remove(name);

                // Convert the ArrayList to a single string
                String data = String.join("\n", list);

                // Convert the string to a byte array
                byte[] bytes = data.getBytes();

                // Create an InputStream from the byte array
                InputStream is = new ByteArrayInputStream(bytes);

                // Create metadata and set content length
                ObjectMetadata meta = new ObjectMetadata();
                meta.setContentLength(bytes.length);

                // Upload the InputStream to S3
                s3.putObject(bucketName, LIST_OBJECT_NAME, is, meta);
            }
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
        }
    }

    /**
     * Reads the list of objects from the S3 bucket
     * @return An ArrayList of strings containing the names of the objects in the bucket
     */
    private ArrayList<String> readObjectListFromS3() {
        try {
            // Download the object from S3
            S3Object o = s3.getObject(bucketName, LIST_OBJECT_NAME);
            InputStream is = o.getObjectContent();

            // Read the object's data into a byte array
            byte[] bytes = is.readAllBytes();

            // Convert the byte array to a string
            String data = new String(bytes);

            // Split the string into an ArrayList of strings
            ArrayList<String> list = new ArrayList<>(Arrays.asList(data.split("\n")));

            return list;
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Deletes an object from the S3 bucket
     * @param object_key The name of the object to delete
     * @return A string containing the result of the operation
     */
    public String deleteObject(String object_key) {
        if (offlineMode) {
            return "Offline mode: cannot delete object from S3 bucket";
        } else {
            try {
                s3.deleteObject(bucketName, object_key);
                removeElementFromList(object_key);
            } catch (AmazonServiceException e) {
                return e.getErrorMessage();
            }
            return "Deletion successful";
        }
    }

    /**
     * Checks if the handler is in offline mode
     * @return A boolean indicating if the handler is in offline mode
     */
    public boolean isOffline() {
        return offlineMode;
    }
}
