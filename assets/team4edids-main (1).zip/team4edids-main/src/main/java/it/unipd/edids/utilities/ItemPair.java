package it.unipd.edids.utilities;

/**
 * Utility class for the pair of an item and its quantity
 */
public class ItemPair implements Comparable<ItemPair> {
    private int id;
    private int quantity;

    /**
     * Default constructor for the ItemPair class
     */
    public ItemPair() {
        this.id = -1;
        this.quantity = 0;
    }

    /**
     * Constructor for the ItemPair class
     *
     * @param id       item id
     * @param quantity item quantity
     */
    public ItemPair(int id, int quantity) {
        this.id = id;
        this.quantity = quantity;
    }

    /**
     * Compares this object with the specified object for order.
     * @param p the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than the specified object.
     */
    @Override
    public int compareTo(ItemPair p) {
        return p.id - this.id;
    }

    public int getId() {
        return id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Returns a string representation of the object
     * @return a string representation of the object
     */
    @Override
    public String toString() {
        return "(" + getId() + "," + getQuantity() + ")";
    }

    /**
     * Indicates whether some other object is "equal to" this one
     * @param obj the reference object with which to compare
     * @return true if this object is the same as the obj argument; false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        try {
            return ((ItemPair) obj).getId() == this.getId();
        } catch (Exception e) {
            return false;
        }
    }
}
