package it.unipd.edids.utilities;

import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * Utility class for the trader messages
 */
@XmlRootElement(name = "traderMessages")
public class TraderMessages {
    private String greetingsMsg;
    private String waitingMsg;
    private String servedMsg;
    private String goodItemMsg;
    private String badItemMsg;

    /**
     * Default constructor for the TraderMessages class
     */
    public TraderMessages() {
        greetingsMsg = "";
    }

    public String getGreetingsMsg() {
        return greetingsMsg;
    }

    public String getWaitingMsg() {
        return waitingMsg;
    }

    public String getServedMsg() {
        return servedMsg;
    }

    public String getGoodItemMsg() {
        return goodItemMsg;
    }

    public String getBadItemMsg() {
        return badItemMsg;
    }

    @Override
    public String toString() {
        return "TraderMessages{" +
                "greetingsMsg='" + greetingsMsg + '\'' +
                ", waitingMsg='" + waitingMsg + '\'' +
                ", servedMsg='" + servedMsg + '\'' +
                ", goodItemMsg='" + goodItemMsg + '\'' +
                ", badItemMsg='" + badItemMsg + '\'' +
                '}';
    }
}
