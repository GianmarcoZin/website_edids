package it.unipd.edids.items;

public class NonPickableItem extends Item {
    private int hp;

    public NonPickableItem() {
        super();
    }

    public NonPickableItem(int id, String name, String description, int hp) {
        super(id, name, description);
        this.hp = hp;
    }

    public int getHp() {
        return hp;
    }

    public void setHp
            (int healing) {
        this.hp = healing;
    }

    @Override
    public String toString() {
        return super.toString() + "->" + "NonPickableItem{" +
                "hp=" + hp +
                '}';
    }
}
