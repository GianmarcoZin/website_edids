package it.unipd.edids.items;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "weaponItem")
public class WeaponItem extends PickableItem {
    private int damage;

    public WeaponItem(int id, String name, String description, int weight, int damage) {
        super(id, name, description, weight);
        this.damage = damage;
    }

    public WeaponItem() {
        super(0, null, null, 0);
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    @Override
    public String toString() {
        return super.toString() + "->" + "WeaponItem{" +
                "damage=" + damage +
                '}';
    }
}
