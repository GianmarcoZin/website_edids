package it.unipd.edids.items;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "consumableItem")
public class ConsumableItem extends PickableItem {
    private int hp;

    public ConsumableItem(int id, String name, String description, int weight, int hp) {
        super(id, name, description, weight);
        this.hp = hp;
    }

    public ConsumableItem(int id, String name, String description, int weight) {
        super(id, name, description, weight);
    }

    public ConsumableItem(ConsumableItem item) {
        super(item.getId(), item.getName(), item.getDescription(), item.getWeight());
        this.hp = item.getHp();
    }

    public ConsumableItem() {
        super(0, null, null, 0);
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    @Override
    public String toString() {
        return super.toString() + "->" + "ConsumableItem{" +
                "hp=" + hp +
                '}';
    }
}
