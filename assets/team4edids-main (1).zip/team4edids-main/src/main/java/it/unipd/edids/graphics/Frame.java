package it.unipd.edids.graphics;

import javax.swing.*;
import java.awt.*;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

public class Frame extends JFrame{
    public static final int FRAME_WIDTH = 1300;
    public static final int FRAME_HEIGHT = 900;
    public static final String ITEM_COLOR = "#24495B";
    public static final String BACKGROUND_COLOR = "#001523";
    public static final String BORDER_COLOR = "#E1DACE";
    public static final Font FONT = new Font("Arial", Font.BOLD, 18);
    public static final int DEFAULT_PANEL_X = 25;
    public static final int DEFAULT_PANEL_Y = 25;
    public static final int DEFAULT_PANEL_WIDTH = 1232;
    public static final int DEFAULT_PANEL_HEIGHT = 530;

    private MapPanel mapPanel;
    private OutputLabel outputLabel;
    private JTextArea inputArea;

    private InventoryPanel inventoryPanel;
    private StatsPanel statsPanel;
    private CombatPanel combatPanel;
    private RoomPanel roomPanel;
    private JPanel defaultPanel;

    private JScrollPane scrollPane;

    public Frame() {
        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.setTitle("Jungle Temple");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setLayout(null);
        this.setFont(FONT);
        //this.getContentPane().setBackground(Color.GRAY);
        this.getContentPane().setBackground(Color.decode(BACKGROUND_COLOR));

        defaultPanel = new JPanel();
        defaultPanel.setBounds(DEFAULT_PANEL_X, DEFAULT_PANEL_Y, DEFAULT_PANEL_WIDTH, DEFAULT_PANEL_HEIGHT);
        defaultPanel.setOpaque(true);
        defaultPanel.setBackground(Color.decode(BACKGROUND_COLOR));
        ImageIcon defaultPanelImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/default-panel.png"));
        defaultPanelImage.setImage(defaultPanelImage.getImage().getScaledInstance(DEFAULT_PANEL_WIDTH, DEFAULT_PANEL_HEIGHT, Image.SCALE_SMOOTH));
        JLabel defaultLabel = new JLabel(defaultPanelImage);
        defaultPanel.add(defaultLabel);
        this.add(defaultPanel);

        ImageIcon logo = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/logo.png"));
        this.setIconImage(logo.getImage());

        mapPanel = new MapPanel();
        this.add(mapPanel);

        this.outputLabel = new OutputLabel();
        scrollPane = new JScrollPane(outputLabel);
        scrollPane.setBounds(outputLabel.getBounds());
        scrollPane.setBorder(BorderFactory.createMatteBorder(OutputLabel.BORDER_SIZE,OutputLabel.BORDER_SIZE,0,OutputLabel.BORDER_SIZE,Color.decode(BORDER_COLOR)));
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        this.add(scrollPane);
        //this.add(outputLabel);

        inputArea = new InputTextArea();
        add(inputArea);

        this.inventoryPanel = new InventoryPanel();
        add(inventoryPanel);

        this.statsPanel = new StatsPanel();
        this.add(statsPanel);

        this.combatPanel = new CombatPanel();
        this.add(combatPanel);

        roomPanel = new RoomPanel();
        this.add(roomPanel);

        setVisiblePanel(PanelChoice.DEFAUL_PANEL);

        this.setVisible(true);
    }

    public void setVisiblePanel(PanelChoice panelChoice){
        combatPanel.setVisible(false);
        roomPanel.setVisible(false);
        defaultPanel.setVisible(false);
        switch (panelChoice){
            case ROOM_PANEL:
                roomPanel.setVisible(true);
                break;
            case COMBAT_PANEL:
                combatPanel.setVisible(true);
                break;
            case DEFAUL_PANEL:
                defaultPanel.setVisible(true);
        }
        waitPaint();
    }

    public JTextArea getInputArea() {
        return inputArea;
    }

    public void removeAllInventoryItems(){
        inventoryPanel.removeAllItems();
        waitPaint();
    }

    public void removeAllRoomItems(){
        roomPanel.removeAllItems();
        waitPaint();
    }

    public void addRoomItem(int itemID){
        roomPanel.addItem(itemID);
        waitPaint();
    }

    public void removeRoomItem(int itemID){
        roomPanel.removeItem(itemID);
        waitPaint();
    }

    public void setRoomPanelEntity(int id){
        roomPanel.setEntity(id);
        waitPaint();
    }

    public void setCombatPanelMonster(int id){
        combatPanel.setMonster(id);
        waitPaint();
    }

    public void setCombatPanelMonsterHp(int hp){
        combatPanel.setMonsterHp(hp);
        waitPaint();
    }

    public void setCombatPanelMonsterMaxHp(int maxHp){
        combatPanel.setMonsterMaxHp(maxHp);
        waitPaint();
    }

    public void setPlayerHp(int hp) {
        statsPanel.setHp(hp);
        combatPanel.setPlayerHp(hp);
        waitPaint();
    }

    public void setPlayerScore(int score) {
        statsPanel.setScore(score);
        waitPaint();
    }

    public void setBossesDefeated(int bossesDefeated) {
        statsPanel.setBossesDefeated(bossesDefeated);
        waitPaint();
    }

    public void setInventoryWeight(int inventoryWeight) {
        statsPanel.setInventoryWeight(inventoryWeight);
        waitPaint();
    }

    public void setRoomVisible(int roomID, boolean visible){
        this.mapPanel.setVisible(roomID, visible);
        waitPaint();
    }

    public void setPlayerPosition(int roomID){
        this.mapPanel.setPlayerPosition(roomID);
        waitPaint();
    }

    public void addInventoryItem(int itemId){
        this.inventoryPanel.addItem(itemId);
        waitPaint();
    }

    public void removeInventoryItem(int itemId){
        this.inventoryPanel.removeItem(itemId);
        waitPaint();
    }

    public void equipItem(int itemId){
        this.inventoryPanel.equipItem(itemId);
        waitPaint();
    }

    public void writeOutput(String output){
        this.outputLabel.write(output);
        AdjustmentListener adjustmentListener = new AdjustmentListener() {
            public void adjustmentValueChanged(AdjustmentEvent e) {
                e.getAdjustable().setValue(e.getAdjustable().getMaximum());
            }
        };
        scrollPane.getVerticalScrollBar().addAdjustmentListener(adjustmentListener);
        waitPaint();
        scrollPane.getVerticalScrollBar().removeAdjustmentListener(adjustmentListener);
    }

    public String readInput(){
        String input = inputArea.getText().trim();
        inputArea.setText("");
        return input;
    }

    private void waitPaint(){
        try{
            SwingUtilities.invokeAndWait(new Thread(new Runnable() {
                @Override
                public void run() {
                    repaint();
                }
            }));
        }catch (Exception e){
            e.printStackTrace();
        }
    }


}
