package it.unipd.edids.graphics;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;
import java.util.Stack;

public class RoomPanel extends JLayeredPane {
    public static final int X = CombatPanel.X;
    public static final int Y = CombatPanel.Y;
    public static final int WIDTH = CombatPanel.WIDTH;
    public static final int HEIGHT = CombatPanel.HEIGHT;
    public static final int ENTITY_Y = 170;
    public static final int ENTITY_SIZE = 170;
    public static final int ENTITY_X = (WIDTH - ENTITY_SIZE) / 2;
    public static final int PLAYER_SIZE = 170;
    public static final int PLAYER_X = 50;
    public static final int PLAYER_Y = 340;
    public static final int ITEMS_X = 190;
    public static final int ITEMS_Y = 400;
    public static final int USE_LOOK_LABEL_SIZE = 100;
    public static final int USE_LOOK_X = 530;
    public static final int USE_LOOK_Y = 390;
    public static final int BORDER_SIZE = CombatPanel.BORDER_SIZE;
    public static final String BORDER_COLOR = Frame.BORDER_COLOR;

    JLabel entityLabel;
    Stack<ItemLabel> items;
    JLabel useLookLabel;

    public RoomPanel() {
        this.items = new Stack<>();

        setLayout(null);
        setBounds(X, Y, WIDTH, HEIGHT);
        setBorder(BorderFactory.createMatteBorder(BORDER_SIZE,BORDER_SIZE,BORDER_SIZE, BORDER_SIZE,Color.decode(BORDER_COLOR)));

        entityLabel = new JLabel();
        entityLabel.setBounds(ENTITY_X, ENTITY_Y, ENTITY_SIZE, ENTITY_SIZE);

        ImageIcon sceneryImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/room/room_scenery.jpeg"));
        sceneryImage.setImage(sceneryImage.getImage().getScaledInstance(WIDTH-2*BORDER_SIZE, HEIGHT-2*BORDER_SIZE, Image.SCALE_SMOOTH));
        JLabel sceneryLabel = new JLabel(sceneryImage);
        sceneryLabel.setBounds(0, 0, WIDTH, HEIGHT);
        setLayer(sceneryLabel, -1);

        JLabel playerLabel = new JLabel();
        playerLabel.setBounds(PLAYER_X, PLAYER_Y, PLAYER_SIZE, PLAYER_SIZE);
        ImageIcon playerImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/room/player.png"));
        playerImage.setImage(playerImage.getImage().getScaledInstance(PLAYER_SIZE, PLAYER_SIZE, Image.SCALE_SMOOTH));
        playerLabel.setIcon(playerImage);

        ImageIcon useLookImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/room/use_look.png"));
        useLookImage.setImage(useLookImage.getImage().getScaledInstance(USE_LOOK_LABEL_SIZE, USE_LOOK_LABEL_SIZE, Image.SCALE_SMOOTH));
        useLookLabel = new JLabel(useLookImage);
        useLookLabel.setBounds(USE_LOOK_X, USE_LOOK_Y, USE_LOOK_LABEL_SIZE, USE_LOOK_LABEL_SIZE);
        useLookLabel.setVisible(false);

        this.add(playerLabel);
        this.add(entityLabel);
        this.add(useLookLabel);
        this.add(sceneryLabel);
        setOpaque(true);
    }

    public void setEntity(int entityID) {
        if (entityID != -1){
            ImageIcon monsterImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/entities/" + entityID + ".png"));
            monsterImage.setImage(monsterImage.getImage().getScaledInstance(ENTITY_SIZE, ENTITY_SIZE, Image.SCALE_SMOOTH));
            entityLabel.setIcon(monsterImage);
        } else {
            entityLabel.setIcon(null);
        }
    }

    public void addItem(int itemID) {
        ItemLabel temp = new ItemLabel(itemID, new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/inventory/" + itemID + ".png")), 1);
        if(items.contains(temp)) {
            ItemLabel itemInList = items.get(items.indexOf(temp));
            itemInList.setQuantity(itemInList.getQuantity() + 1);
        }else{
            items.push(temp);
            temp.setVisible(false);
            add(temp);
            if(items.size() <= 3){
                temp.setLocation(ITEMS_X + (items.size() - 1) * ItemLabel.LABEL_WIDTH, ITEMS_Y);
                temp.setVisible(true);
            }
        }
        if(items.size() > 3){
            useLookLabel.setVisible(true);
        }
    }

    public void removeAllItems(){
        while(!items.isEmpty()) {
            remove(items.pop());
        }
    }

    public void removeItem(int itemID) {
        ItemLabel temp = new ItemLabel(itemID, null, 0);
        if(items.contains(temp)){
            ItemLabel itemInList = items.get(items.indexOf(temp));
            itemInList.setQuantity(itemInList.getQuantity() - 1);
            if (itemInList.getQuantity() == 0) {
                if (items.size() >= 2 && !itemInList.equals(items.peek())) {
                    items.peek().setLocation(itemInList.getX(), itemInList.getY());
                    items.peek().setVisible(true);
                    replaceInStack(itemInList, items.peek());
                }
                items.pop();
                remove(itemInList);
            }
        }
        if(items.size() <= 3){
            useLookLabel.setVisible(false);
        }
    }

    private void replaceInStack(ItemLabel toBeReplaced, ItemLabel replacement) {
        Stack<ItemLabel> tempStack = new Stack<>();
        while (!items.peek().equals(toBeReplaced)) {
            tempStack.push(items.pop());
        }
        items.pop();
        items.push(replacement);
        while (!tempStack.isEmpty()) {
            items.push(tempStack.pop());
        }
    }
}
