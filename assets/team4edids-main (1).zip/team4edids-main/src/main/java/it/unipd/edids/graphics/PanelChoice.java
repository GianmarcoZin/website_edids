package it.unipd.edids.graphics;

public enum PanelChoice {
    ROOM_PANEL,
    COMBAT_PANEL,
    DEFAUL_PANEL
}
