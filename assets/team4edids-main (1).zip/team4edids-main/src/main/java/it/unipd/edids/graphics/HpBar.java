package it.unipd.edids.graphics;

import javax.swing.*;
import java.awt.*;

public class HpBar extends JPanel {
    public static final int WIDTH = 124;
    public static final int HEIGHT = 19;
    public static final int HP_BAR_WIDTH = 120;
    public static final int HP_BAR_HEIGHT = 15;
    public static final int DEFAULT_HP = 100;

    private int maxHp;
    private JLabel hpBar;
    private JLabel hpText;

    //coordinates
    public HpBar(int x, int y) {
        this.maxHp = DEFAULT_HP;
        this.setBounds(x, y, WIDTH, HEIGHT);
        this.setLayout(null);
        this.setBackground(Color.WHITE);
        this.setOpaque(true);
        hpText = new JLabel();
        hpText.setBounds(2, 2, HP_BAR_WIDTH, HP_BAR_HEIGHT);
        Font fontTemp = new Font(Frame.FONT.getFontName(), Frame.FONT.getStyle(), Frame.FONT.getSize() - 4);
        hpText.setFont(fontTemp);
        hpText.setText(maxHp + " HP");
        hpBar = new JLabel();
        hpBar.setBounds(2, 2, HP_BAR_WIDTH, HP_BAR_HEIGHT);
        hpBar.setBackground(Color.GREEN);
        hpBar.setOpaque(true);
        add(hpText);
        add(hpBar);
    }

    public void setHp(int hp) {
        hpText.setText(hp + " HP");
        double hpInPercentage = (double) hp / maxHp;
        hpBar.setSize((int) (HP_BAR_WIDTH * hpInPercentage), HP_BAR_HEIGHT);
        if (hpInPercentage > 0.7) {
            hpBar.setBackground(Color.GREEN);
        }else if(hpInPercentage > 0.4) {
            hpBar.setBackground(Color.ORANGE);
        }else{
            hpBar.setBackground(Color.RED);
        }
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }
}
