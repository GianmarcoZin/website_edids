package it.unipd.edids.amazon;

import it.unipd.edids.utilities.Paths;

import java.io.IOException;
import java.util.Objects;
import java.util.Properties;

/**
 * Class for reading the AWS properties from the credentials file
 */
public class AWSPropertiesReader {
    /**
     * Reads the AWS properties from the credentials file
     * @return Properties object containing the s3 properties
     * @throws IOException if the file is not found
     */
    public static Properties readAuthProperties() throws IOException {
        Properties auth = new Properties();
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        auth.load(Objects.requireNonNull(classLoader.getResource(Paths.AWS_CREDENTIALS_FILE).openStream()));
        return auth;
    }
}
