package it.unipd.edids.entities;

import it.unipd.edids.utilities.TraderMessages;
import it.unipd.edids.utilities.TraderState;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;


/**
 * Class about trader character
 */
@XmlRootElement(name = "trader")
@XmlAccessorType(XmlAccessType.FIELD)
public class Trader extends Entity {
    private int givenItemID;
    private TraderState state;
    @XmlElement(name = "traderMessages")
    private TraderMessages messages;

    /**
     * Constructor
     *
     * @param drop        Item that the trader gives
     * @param givenItemID Item that player gives to the trader
     */
    public Trader(int id, String name, int drop, int givenItemID) {
        super(id, name, drop);
        this.givenItemID = givenItemID;
        this.state = TraderState.GREETING;
    }

    public Trader() {
        super(-1, null, -1);
        this.givenItemID = -1;
        this.state = TraderState.GREETING;
    }

    public Trader(int id, String name) {
        super(id, name, -1);
        this.state = TraderState.GREETING;
    }

    public String talk() {
        switch (state) {
            case GREETING:
                if (getDropID() < 0) {
                    return getName() + ": " + messages.getGreetingsMsg();
                } else {
                    setState(TraderState.WAITING);
                    return getName() + ": " + messages.getGreetingsMsg() + "<br>" + getName() + ": " + messages.getWaitingMsg();
                }
            case WAITING:
                return getName() + ": " + messages.getWaitingMsg();
            case SERVED:
                return getName() + ": " + messages.getServedMsg();
            default:
                return null;
        }
    }

    public void setGivenItem(int givenItem) {
        this.givenItemID = givenItem;
    }

    // Allow trader to accept item, if the item is correct it returns the trader specific reward item
    public int acceptItem(int givenItemID) {
        if (this.givenItemID == givenItemID) {
            state = TraderState.SERVED;
            return getDropID();
        }
        return -1;
    }

    public int getGivenItem() {
        return givenItemID;
    }

    public TraderState getState() {
        return state;
    }

    public void setState(TraderState state) {
        this.state = state;
    }

    public TraderMessages getMessages() {
        return messages;
    }

    public void setMessages(TraderMessages messages) {
        this.messages = messages;
    }

    @Override
    public String toString() {
        return super.toString() + "->" + "Trader{" +
                "givenItemID=" + givenItemID +
                ", state=" + state +
                ", messages=" + messages +
                '}';
    }
}

