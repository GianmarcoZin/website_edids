package it.unipd.edids.entities;

public abstract class Entity implements Comparable<Entity> {
    private int id;
    private int dropID;
    private String name;

    public Entity(int id, String name, int drop) {
        this.id = id;
        this.name = name;
        this.dropID = drop;
    }

    public int dropItem() {
        int temp = dropID;
        dropID = -1;
        return temp;
    }

    public String getName() {
        return name;
    }

    public int getDropID() {
        return dropID;
    }

    public void setDropID(int dropId) {
        this.dropID = dropId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int compareTo(Entity o) {
        return this.id - o.getId();
    }

    @Override
    public boolean equals(Object obj) {
        try {
            return ((Entity) obj).getId() == this.getId();
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public String toString() {
        return "Entity{" +
                "id=" + id +
                ", dropID=" + dropID +
                ", name='" + name + '\'' +
                '}';
    }
}
