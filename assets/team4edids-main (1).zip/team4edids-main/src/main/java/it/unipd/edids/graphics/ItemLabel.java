package it.unipd.edids.graphics;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import java.awt.*;

public class ItemLabel extends JLabel {
    private int id;
    private int quantity;
    /*
    public static final int LABEL_HEIGHT = 80;
    public static final int LABEL_WIDTH = 160;
    public static final int LABEL_BORDER_SIZE = 3;
    */
    public static final int LABEL_HEIGHT = 80;
    public static final int LABEL_WIDTH = InventoryPanel.PANEL_WIDTH/2;
    public static final int LABEL_BORDER_SIZE = 3;
    public static final int THIN_BORDER = 2;
    public static final int PADDING = 5;
    public static final int IMAGE_SIZE = 60;
    public static final String BACKGROUND_COLOR = Frame.ITEM_COLOR;
    public static final String OUTSIDE_COLOR = Frame.BACKGROUND_COLOR;
    public static final String BORDER_COLOR = Frame.BORDER_COLOR;

    public ItemLabel(int id, ImageIcon image, int quantity) {
        this.id = id;
        setQuantity(quantity);
        setFont(Frame.FONT);
        if (image != null)
            setIcon(new ImageIcon(image.getImage().getScaledInstance(IMAGE_SIZE, IMAGE_SIZE, Image.SCALE_SMOOTH)));
        setSize(LABEL_WIDTH, LABEL_HEIGHT);
    }

    /*
    public void setLeftUpperPadding(int leftPadding, int upperPadding) {
        //setBounds(leftPadding, upperPadding, LABEL_WIDTH, LABEL_HEIGHT);
        setLocation(leftPadding, upperPadding);
    }
    */

    public int getId() {
        return id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        if(quantity > 1){
            setText("X " + quantity);
        }else{
            setText("");
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ItemLabel) {
            return ((ItemLabel) obj).id == this.id;
        } else {
            return false;
        }
    }
}