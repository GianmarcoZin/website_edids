package it.unipd.edids.jakarta.wrappers;

import it.unipd.edids.items.NonPickableItem;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

/**
 * Wrapper utility class for the list of non-pickable items
 */
@XmlRootElement(name = "nonPickableItems")
@XmlAccessorType(XmlAccessType.FIELD)
public class NonPickableItemList {
    @XmlElement(name = "nonPickableItem")
    private List<NonPickableItem> nonPickableItemList;

    /**
     * Default constructor for the NonPickableItemList class
     */
    public NonPickableItemList() {
    }

    /**
     * Constructor for the NonPickableItemList class
     *
     * @param nonPickableItemList list of non-pickable items
     */
    public NonPickableItemList(List<NonPickableItem> nonPickableItemList) {
        this.nonPickableItemList = nonPickableItemList;
    }

    /**
     * Getter for the list of non-pickable items
     *
     * @return list of non-pickable items
     */
    public List<NonPickableItem> getNonPickableItemList() {
        return nonPickableItemList;
    }

    /**
     * Setter for the list of non-pickable items
     *
     * @param nonPickableItemList list of non-pickable items
     */
    public void setNonPickableItemList(List<NonPickableItem> nonPickableItemList) {
        this.nonPickableItemList = nonPickableItemList;
    }
}
