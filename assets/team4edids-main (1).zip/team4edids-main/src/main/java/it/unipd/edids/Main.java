package it.unipd.edids;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        //System.out.println(AES256Encryption.decrypt("7Q8vAmHTBnN7zhTMoMsYJTd/TLnS9xL6ru74DFuxCOuzUpo5V566Nnooa80HNR3H", "ScrumMaster"));
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            Controller controller = new Controller();
            controller.run();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}