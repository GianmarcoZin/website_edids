package it.unipd.edids.graphics;

import javax.swing.*;
import java.awt.*;

public class CombatPanel extends JLayeredPane {
    public static final int WIDTH = 680;
    public static final int X = (Frame.FRAME_WIDTH - WIDTH) / 2;
    public static final int Y = 25;
    public static final int HEIGHT = 550 - Y;
    public static final int MONSTER_Y = 150;
    public static final int MONSTER_SIZE = 170;
    public static final int PLAYER_SIZE = 170;
    public static final int PLAYER_Y = 170;
    public static final int MONSTER_HP_BAR_X = (WIDTH / 3) * 2 + 30;
    public static final int PLAYER_HP_BAR_X = WIDTH / 6 + 20;
    public static final int MONSTER_HP_BAR_Y = 120;
    public static final int PLAYER_HP_BAR_Y = 170;
    public static final String BORDER_COLOR = Frame.BORDER_COLOR;
    public static final int BORDER_SIZE = 2;
    private JLabel monsterLabel;
    private HpBar monsterHpBar;
    private HpBar playerHpBar;

    public CombatPanel() {
        setLayout(null);
        setBounds(X, Y, WIDTH, HEIGHT);
        //setBorder(BorderFactory.createLineBorder(Color.decode(BORDER_COLOR)));
        setBorder(BorderFactory.createMatteBorder(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, Color.decode(BORDER_COLOR)));

        monsterLabel = new JLabel();
        monsterLabel.setBounds((WIDTH / 3) * 2, MONSTER_Y, MONSTER_SIZE, MONSTER_SIZE);
        this.monsterHpBar = new HpBar(MONSTER_HP_BAR_X, MONSTER_HP_BAR_Y);
        this.add(monsterHpBar);

        this.playerHpBar = new HpBar(PLAYER_HP_BAR_X, PLAYER_HP_BAR_Y);
        this.add(playerHpBar);
        ImageIcon sceneryImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/room/combat_scenery.jpeg"));
        sceneryImage.setImage(sceneryImage.getImage().getScaledInstance(WIDTH - 2 * BORDER_SIZE, HEIGHT - 2 * BORDER_SIZE, Image.SCALE_SMOOTH));
        JLabel sceneryLabel = new JLabel(sceneryImage);
        sceneryLabel.setBounds(0, 0, WIDTH, HEIGHT);

        JLabel playerLabel = new JLabel();
        playerLabel.setBounds(WIDTH / 6, PLAYER_Y, PLAYER_SIZE, PLAYER_SIZE);
        ImageIcon playerImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/room/player.png"));
        playerImage.setImage(playerImage.getImage().getScaledInstance(PLAYER_SIZE, PLAYER_SIZE, Image.SCALE_SMOOTH));
        playerLabel.setIcon(playerImage);

        this.add(playerLabel);
        this.add(monsterLabel);
        this.add(sceneryLabel);
        setOpaque(true);
    }

    public void setMonster(int monsterID) {
        if (monsterID != -1) {
            ImageIcon monsterImage = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("img/entities/" + monsterID + ".png"));
            monsterImage.setImage(monsterImage.getImage().getScaledInstance(MONSTER_SIZE, MONSTER_SIZE, Image.SCALE_SMOOTH));
            monsterLabel.setIcon(monsterImage);
        }
    }

    public void setMonsterHp(int monsterHp) {
        monsterHpBar.setHp(monsterHp);
    }

    public void setMonsterMaxHp(int maxHp) {
        monsterHpBar.setMaxHp(maxHp);
    }

    public void setPlayerHp(int playerHp) {
        playerHpBar.setHp(playerHp);
    }
}
