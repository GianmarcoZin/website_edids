package it.unipd.edids;

import java.util.ArrayList;

public class Map {
    private ArrayList<Room> gameMap;
    private int teleportRoomID;
    private int bossRoomID;

    public Map(ArrayList<Room> gameMap) {
        this.gameMap = gameMap;
        this.teleportRoomID = -1;
        this.bossRoomID = -1;
    }

    public ArrayList<Room> getGameMap() {
        return gameMap;
    }

    public Room getRoom(int index) {
        return gameMap.get(index);
    }

    public void setGameMap(ArrayList<Room> gameMap) {
        this.gameMap = gameMap;
    }

    public int getTeleportRoomID() {
        return teleportRoomID;
    }

    public void setTeleportRoomID(int teleportRoomID) {
        this.teleportRoomID = teleportRoomID;
    }

    public int getBossRoomID() {
        return bossRoomID;
    }

    public void setBossRoomID(int bossRoomID) {
        this.bossRoomID = bossRoomID;
    }

    public int getSize(){
        return gameMap.size();
    }

    @Override
    public String toString() {
        return "Map{" +
                "gameMap=" + gameMap +
                ", teleportRoomID=" + teleportRoomID +
                ", bossRoomID=" + bossRoomID +
                '}';
    }
}
