package it.unipd.edids.utilities;

/**
 * Utility class for the paths of the XML files
 */
public class Paths {
    public static final String PATH_CONSUMABLE_ITEMS = "items/consumable_items.xml";
    public static final String PATH_NON_PICKABLE_ITEMS = "items/non_pickable_items.xml";
    public static final String PATH_PICKABLE_ITEMS = "items/pickable_items.xml";
    public static final String PATH_WEAPON_ITEMS = "items/weapon_items.xml";

    public static final String PATH_ROOMS = "rooms.xml";

    public static final String PATH_TRADERS = "entities/traders.xml";
    public static final String PATH_MONSTERS = "entities/monsters.xml";

    public static final String PATH_NEW_GAME_SAVE = "new_game_save.xml";

    public static final String AWS_CREDENTIALS_FILE = "aws_config/s3credential.properties";
}
