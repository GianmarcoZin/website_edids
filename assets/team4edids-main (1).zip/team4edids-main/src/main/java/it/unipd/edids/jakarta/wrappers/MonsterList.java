package it.unipd.edids.jakarta.wrappers;

import it.unipd.edids.entities.Monster;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

/**
 * Wrapper utility class for the list of monsters
 */
@XmlRootElement(name = "monsters")
@XmlAccessorType(XmlAccessType.FIELD)
public class MonsterList {
    @XmlElement(name = "monster")
    private List<Monster> monsterList;

    /**
     * Default constructor for the MonsterList class
     */
    public MonsterList() {
    }

    /**
     * Constructor for the MonsterList class
     *
     * @param monsterList list of monsters
     */
    public MonsterList(List<Monster> monsterList) {
        this.monsterList = monsterList;
    }

    /**
     * Getter for the list of monsters
     *
     * @return list of monsters
     */
    public List<Monster> getMonsterList() {
        return monsterList;
    }

    /**
     * Setter for the list of monsters
     *
     * @param monsterList list of monsters
     */
    public void setMonsterList(List<Monster> monsterList) {
        this.monsterList = monsterList;
    }
}
