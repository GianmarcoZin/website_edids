package it.unipd.edids;

import it.unipd.edids.entities.Entity;
import it.unipd.edids.utilities.Direction;
import it.unipd.edids.utilities.ItemPair;
import jakarta.xml.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;

@XmlRootElement(name = "room")
@XmlAccessorType(XmlAccessType.FIELD)
public class Room implements Comparable<Room> {
    private int id;
    private String name;
    private String description;
    @XmlElement(name = "items")
    private ArrayList<ItemPair> items; // Entry(id, quantità) list of item in the room
    @XmlElement(name = "entities")
    private ArrayList<Entity> entities; // list of entities in the room
    @XmlElementWrapper(name = "passages")
    @XmlElement(name = "value")
    private int[] passages; // list of passages 0: north, 1: east, 2: south, 3: west
    private boolean isDiscovered; // if the room is discovered by the player

    /**
     * Constructor
     */
    public Room() {
        items = new ArrayList<ItemPair>();
        entities = new ArrayList<Entity>();
        passages = new int[4];
        Arrays.fill(passages, -1);
        isDiscovered = false;
    }

    /**
     * Return a specific passage
     *
     * @param direction
     * @return
     */
    public int getPassage(Direction direction) {
        return passages[direction.ordinal()];
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ArrayList<ItemPair> getItems() {
        return items;
    }

    public void setItems(ArrayList<ItemPair> items) {
        this.items = items;
    }

    public ArrayList<Entity> getEntities() {
        return entities;
    }

    public void setEntities(ArrayList<Entity> entities) {
        this.entities = entities;
    }

    public int[] getPassages() {
        return passages;
    }

    public void setPassages(int[] passages) {
        this.passages = passages;
    }

    public boolean isDiscovered() {
        return isDiscovered;
    }

    public void setDiscovered(boolean discovered) {
        isDiscovered = discovered;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Room o) {
        return this.id - o.id;
    }

    public void addItem(int pairID) {
        if (hasItem(pairID)) {
            int indexItem = items.indexOf(new ItemPair(pairID, 0));
            items.get(indexItem).setQuantity(items.get(indexItem).getQuantity() + 1);
        } else {
            items.add(new ItemPair(pairID, 1));
        }
    }

    public void removeItem(int itemID) throws Exception {
        if (!hasItem(itemID))
            throw new Exception("Invalid item ID");
        int ind = items.indexOf(new ItemPair(itemID, 0));
        if (items.get(ind).getQuantity() == 1)
            items.remove(ind);
        else
            items.get(ind).setQuantity(items.get(ind).getQuantity() - 1);
    }

    public boolean hasItem(int itemID) {
        if (items.indexOf(new ItemPair(itemID, 0)) == -1)
            return false;
        else
            return true;
    }

    @Override
    public String toString() {
        return "Room{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", items=" + items +
                ", entities=" + entities +
                ", passages=" + Arrays.toString(passages) +
                ", isDiscovered=" + isDiscovered +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        try {
            return ((Room) obj).getId() == this.getId();
        } catch (Exception e) {
            return false;
        }
    }
}
