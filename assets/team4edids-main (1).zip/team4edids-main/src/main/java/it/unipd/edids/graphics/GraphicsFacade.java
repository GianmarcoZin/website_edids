package it.unipd.edids.graphics;

import it.unipd.edids.Game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.util.concurrent.Semaphore;

public class GraphicsFacade {
    private Frame frame;
    private Game game;
    private Semaphore enterPressed;

    public GraphicsFacade() {
        frame = new Frame();
        enterPressed = new Semaphore(0);
        frame.getInputArea().addKeyListener(new EnterKeyListener());
    }

    public void loadInventoryItems() {
        if(game != null){
            frame.removeAllInventoryItems();
            for (int i = 0; i < game.getPlayer().getInventory().size(); i++) {
                for (int j = 0; j < game.getPlayer().getInventory().get(i).getQuantity(); j++) {
                    frame.addInventoryItem(game.getPlayer().getInventory().get(i).getId());
                }
            }
            frame.equipItem(game.getPlayer().getEquippedID());
        }
    }

    public void updateFight() {
        if (game.getCombatTargetID() != -1) {
            frame.setVisiblePanel(PanelChoice.COMBAT_PANEL);
            frame.setCombatPanelMonster(game.getCombatTargetID());
            frame.setCombatPanelMonsterMaxHp(game.getCombatTarget().getMaxHp());
            frame.setCombatPanelMonsterHp(game.getCombatTarget().getHp());
        } else {
            frame.setVisiblePanel(PanelChoice.ROOM_PANEL);
        }
        frame.setPlayerHp(game.getPlayer().getHP());
        frame.setBossesDefeated(game.getPlayer().getBossesDefeated());
        frame.setPlayerScore(game.getPlayer().getScore());
        movePlayer();
    }

    public void takeItem(String item) throws Exception {
        frame.addInventoryItem(game.getItemID(item));
        frame.removeRoomItem(game.getItemID(item));
        frame.setInventoryWeight(game.getPlayer().getInventoryWeight());
    }

    public void equipItem(String item) throws Exception {
        frame.equipItem(game.getItemID(item));
    }

    public void dropItem(String item) throws Exception {
        frame.removeInventoryItem(game.getItemID(item));
        frame.addRoomItem(game.getItemID(item));
        frame.setInventoryWeight(game.getPlayer().getInventoryWeight());
    }

    public void giveItem(String item) throws Exception {
        frame.removeInventoryItem(game.getItemID(item));
        frame.setInventoryWeight(game.getPlayer().getInventoryWeight());
        loadInventoryItems();
    }

    public void useItem(String item) throws Exception {
        frame.removeInventoryItem(game.getItemID(item));
        frame.setPlayerHp(game.getPlayer().getHP());
        frame.setInventoryWeight(game.getPlayer().getInventoryWeight());

    }

    public void movePlayer() {
        for (int i = 0; i < game.getGameMap().getSize(); i++) {
            frame.setRoomVisible(game.getGameMap().getRoom(i).getId(), game.getGameMap().getRoom(i).isDiscovered());
        }
        frame.setPlayerPosition(game.getPlayerPosition());

        frame.removeAllRoomItems();
        for (int i = 0; i < game.getGameMap().getRoom(game.getPlayerPosition()).getItems().size(); i++) {
            for (int j = 0; j < game.getGameMap().getRoom(game.getPlayerPosition()).getItems().get(i).getQuantity(); j++) {
                frame.addRoomItem(game.getGameMap().getRoom(game.getPlayerPosition()).getItems().get(i).getId());
            }
        }

        if (game.getGameMap().getRoom(game.getPlayerPosition()).getEntities().size() > 1) {
            if ((game.getGameMap().getRoom(game.getPlayerPosition()).getEntities().getFirst().getName().equals("Mysterious Mummy"))) {
                frame.setRoomPanelEntity(game.getGameMap().getRoom(game.getPlayerPosition()).getEntities().getLast().getId());
            } else {
                frame.setRoomPanelEntity(game.getGameMap().getRoom(game.getPlayerPosition()).getEntities().getFirst().getId());
            }
        } else if (game.getGameMap().getRoom(game.getPlayerPosition()).getEntities().size() == 1) {
            frame.setRoomPanelEntity(game.getGameMap().getRoom(game.getPlayerPosition()).getEntities().getFirst().getId());
        } else {
            frame.setRoomPanelEntity(-1);
        }
    }

    public void setDefaultPanel() {
        frame.setVisiblePanel(PanelChoice.DEFAUL_PANEL);
    }

    public String readInput() {
        return frame.readInput();
    }

    public void writeOutput(String s) {
        frame.writeOutput(s);
    }

    public Semaphore getEnterPressed() {
        return enterPressed;
    }

    public void close() {
        frame.dispose();
        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
    }

    public void setGame(Game game) {
        this.game = game;
    }

    private class EnterKeyListener implements KeyListener {
        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER && enterPressed.getQueueLength() == 1) {
                enterPressed.release();
            }
        }
    }
}
