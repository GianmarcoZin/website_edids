package it.unipd.edids.graphics;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.text.html.StyleSheet;
import java.awt.*;

public class OutputLabel extends JLabel {
    public static final int X = InputTextArea.X;
    public static final int HEIGHT = 180;
    public static final int WIDTH = InputTextArea.WIDTH;
    public static final int TEXT_WIDTH = 945;
    public static final int Y = Frame.FRAME_HEIGHT - InputTextArea.BOTTOM_PADDING - InputTextArea.HEIGHT - HEIGHT;
    public static final String BORDER_COLOR = Frame.BORDER_COLOR;
    public static final String BACKGROUND_COLOR = Frame.BACKGROUND_COLOR;
    public static final int BORDER_SIZE = InputTextArea.BORDER_SIZE;
    public String text;

    public OutputLabel() {
        this.setBackground(Color.decode(BACKGROUND_COLOR));
        this.setOpaque(true);
        this.setFont(Frame.FONT);
        this.setForeground(Color.WHITE);
        this.setVerticalAlignment(JLabel.TOP);
        this.setBounds(X, Y, WIDTH, HEIGHT);
        this.text = "";
    }

    public void write(String text){
        this.text += "<p style='margin-bottom: 6px'>" + text + "</p>";
        setText("<html><div style='padding: 15px; width: " + TEXT_WIDTH + "px; margin-left: 0;'>" + this.text + "</div></html>");
    }
}
