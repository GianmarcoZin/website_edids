package it.unipd.edids;

import it.unipd.edids.amazon.AWSS3Handler;
import it.unipd.edids.graphics.GraphicsFacade;
import it.unipd.edids.jakarta.Loader;
import it.unipd.edids.jakarta.Saver;
import it.unipd.edids.utilities.Direction;
import it.unipd.edids.utilities.Paths;

import java.util.*;
import java.util.Map.Entry;

public class Controller implements Runnable {
    private Game game;
    private final HashMap<String, String> combatCommands;
    private final HashMap<String, String> alwaysAllowedCommands;
    private final HashMap<String, String> genericCommands;
    private boolean playerHasMoved;
    private boolean goToStartMenu;
    private String saveName;
    private ArrayList<String> saveList;
    private AWSS3Handler s3Handler;
    private GraphicsFacade graphicsFacade;

    public Controller() {
        graphicsFacade = new GraphicsFacade();
        combatCommands = new HashMap<String, String>();
        combatCommands.put("attack", "");
        combatCommands.put("parry", "");

        alwaysAllowedCommands = new HashMap<String, String>();
        alwaysAllowedCommands.put("move", "direction\n move to a different room [north, south, east, ovest]\ne.g. move north | move n");
        alwaysAllowedCommands.put("back", "\n go back to the previous room");
        alwaysAllowedCommands.put("save", "");
        alwaysAllowedCommands.put("exit", "");
        alwaysAllowedCommands.put("equip", "");
        alwaysAllowedCommands.put("inventory", "");
        alwaysAllowedCommands.put("use", "{item}");
        alwaysAllowedCommands.put("help", "");

        genericCommands = new HashMap<String, String>();
        genericCommands.put("look", "");
        genericCommands.put("talk", "");
        genericCommands.put("give", "{item} {entity}");
        genericCommands.put("drop", "{item}");
        genericCommands.put("take", "{item}");

        this.playerHasMoved = true;
        this.goToStartMenu = true;

        s3Handler = new AWSS3Handler();
        if (!s3Handler.isOffline()) {
            saveList = s3Handler.getObjectList();
        }
    }

    @Override
    public void run() {
        try {
            //Scanner scanner = new Scanner(System.in);

            ArrayList<String> userCommand;
            int oldCombatTarget = -1;

            do {
                while (goToStartMenu){
                    if (!startMenu()) {
                        Thread.sleep(1000);
                        graphicsFacade.close();
                    }
                    if (game != null){
                        graphicsFacade.setGame(game);
                        graphicsFacade.loadInventoryItems();
                    }
                }

                // prints the room name and description
                if (playerHasMoved){
                    enterRoom();
                    graphicsFacade.movePlayer();
                }

                if (game.startCombat() && (game.getCombatTargetID() != oldCombatTarget)) {
                    write("You've encountered a " + game.getCombatTarget().getName() + "!");
                    oldCombatTarget = game.getCombatTargetID();
                }
                graphicsFacade.updateFight();
                // TODO pensare cosa fare se attacco
//                if (game.isCombat()) {
//                    System.out.print("# ");
//                    //graphicsFacade.setCombatBackground();
//                } else {
//                    System.out.print("> ");
//                }
                write("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                userCommand = parseUserInput(read());

                try {
                    interpretCommand(userCommand);

                    if (game.getCombatTargetID() != -1)
                        write("You've received " + game.npcAttack() + " from " + game.getCombatTarget().getName());
                } catch (Exception e) {
                    write(e.getMessage());
                }

                if (game.isGameOver()){
                    if (game.getPlayer().getBossesDefeated() != 4) {
                        write(game.gameOver());
                    } else {
                        write(game.win());
                    }
                    goToStartMenu = true;
                    graphicsFacade.setDefaultPanel();
                    write("Press any key to continue");
                    read();
                }
            } while (true);
        } catch (Exception e) {
            write(e.getMessage());
        }
    }

    private String read() {
        String userInput;
        try {
            graphicsFacade.getEnterPressed().acquire();
        } catch (InterruptedException e) {
            write(e.getMessage());
        }

        userInput = graphicsFacade.readInput();
        return userInput;
    }

    private void write(String s) {
        graphicsFacade.writeOutput(s);
    }

    private void enterRoom() {
        playerHasMoved = false;
        write(game.getCurrentRoomName().toUpperCase());
        write(game.getCurrentRoomDescription());
    }


    public boolean startMenu() throws Exception {
        graphicsFacade.setDefaultPanel();
        boolean checkNumber = false;
        goToStartMenu = false;
        String userInput;

        write("Welcome Jungle Temple game!");
        write("Choose an option:");
        write("1) New game");
        write("2) Load save");
        write("3) Exit");

        // ok
        do {
            if (checkNumber)
                write("Invalid command");
            userInput = read();
            checkNumber = true;
        } while (userInput == null || !userInput.matches("^[1-3]$"));


        switch (Integer.parseInt(userInput)) {
            // ok
            case 1:
                game = Loader.loadSave(Paths.PATH_NEW_GAME_SAVE, s3Handler);
                if (!s3Handler.isOffline()) {
                    boolean validSaveName;
                    do {
                        validSaveName = true;
                        write("Name the new save:");
                        saveName = read().toLowerCase().trim();
                        if (Saver.alreadyExistingSaveName(saveName, s3Handler) || saveName.length() < 3) {
                            write("Save name already exists or too short (<3), choose another one");
                            validSaveName = false;
                        } else {
                            write(Saver.saveGame(game, saveName, s3Handler));
                            saveList = s3Handler.getObjectList();
                        }
                    } while (!validSaveName); // check if the save has been created successfully (success = true)
                    playerHasMoved = true;
                }
                break;
            case 2:
                if (!s3Handler.isOffline()) {
                    ArrayList<String> menuInput;
                    boolean loop = true;
                    do {

                        write("Saves list: ");
                        if (saveList.isEmpty()) write("No saves found");
                        for (String s : saveList) {
                            write("- " + s);
                        }

                        write("load/delete [save-name] or back:");

                        menuInput = parseUserInput(read());

                        if (menuInput.get(0).equals("back")) {
                            goToStartMenu = true;
                            loop = false;
                        }
                        if (menuInput.get(0).equals("load") || menuInput.get(0).equals("delete")) {
                            if (!saveList.contains(getFirstArgument(menuInput))) {
                                write("File not found.");
                            } else {
                                if (menuInput.get(0).equals("load")) {
                                    game = Loader.loadSave(getFirstArgument(menuInput), s3Handler);
                                    playerHasMoved = true;
                                    saveName = getFirstArgument(menuInput);
                                    loop = false;
                                } else if (menuInput.get(0).equals("delete")) {
                                    //System.out.println(getFirstArgument(menuInput));
                                    write(Saver.deleteSave(getFirstArgument(menuInput), s3Handler));
                                    saveList = s3Handler.getObjectList();
                                    write(getFirstArgument(menuInput) + " has been deleted");
                                }
                            }
                        }
                    } while (loop);
                } else {
                    write("Not available in offline mode");
                    goToStartMenu = true;
                }
                break;
            case 3:
                write("Until we meet again!");
                return false;
        }
        return true;
    }

    public static String printCommands(HashMap<String, String> list) {
        String s = "";

        // loop that print the list key and value
        for (Entry<String, String> entry : list.entrySet()) {
            s += "-" + entry.getKey() + " " + entry.getValue() + "\n";
        }
        return s + "\n";
    }

    // Ritorna un ArrayList di stringhe che corrisponde a ciascuna parola del comando
    // e.g. "Give bread Elf!!!" -> ["give", "bread", "elf"]
    public static ArrayList<String> parseUserInput(String input) {
        String userInput = input.toLowerCase().trim();
        return new ArrayList<>(Arrays.asList(userInput.split(" ")));
    }

    public void interpretCommand(ArrayList<String> command) throws Exception {
        // check for 0 argument commands
        if (!(command.getFirst().equals("move") ||
                command.getFirst().equals("use") ||
                command.getFirst().equals("give") ||
                command.getFirst().equals("drop") ||
                command.getFirst().equals("equip") ||
                command.getFirst().equals("talk") ||
                command.getFirst().equals("take")) &&
                command.size() != 1) {
            throw new Exception("Invalid number of arguments");
        }

        switch (command.getFirst()) {
            case "attack":
                write(game.attack());
                break;
            case "look":
                write(game.look());
                break;
            case "inventory":
                write(game.getPlayerInventory());
                break;
            case "stats":
                write(game.getPlayerStats());
                break;
            case "exit":
                if (!s3Handler.isOffline()) {
                    String input = "";
                    do {
                        write("Do you want to save? [yes/no]");
                        input = read().toLowerCase().trim();
                    } while (!input.equalsIgnoreCase("yes") && !input.equalsIgnoreCase("no")
                            && !input.equalsIgnoreCase("y") && !input.equalsIgnoreCase("n"));

                    if (input.equalsIgnoreCase("yes") || input.equalsIgnoreCase("y")) {
                        write(Saver.saveGame(game, saveName, s3Handler));
                        write("Game saved");
                    }
                }
                goToStartMenu = true;
                break;
            case "parry":
                if (game.parry()) {
                    write("You've parried the hit!");
                } else {
                    write("The monster broke your guard!");
                }
                break;
            case "move":
                if (game.getCombatTargetID() != -1) {
                    write("You've received " + game.npcAttack() + " from " + game.getCombatTarget().getName());
                }
                boolean exitTeleport = false;
                // first argument is direction
                switch (getFirstArgument(command)) {
                    case "north":
                    case "n":
                        exitTeleport = game.move(Direction.NORTH);

                        break;
                    case "east":
                    case "e":
                        exitTeleport = game.move(Direction.EAST);

                        break;
                    case "south":
                    case "s":
                        exitTeleport = game.move(Direction.SOUTH);

                        break;
                    case "west":
                    case "w":
                        exitTeleport = game.move(Direction.WEST);
                        break;
                    default:
                        throw new Exception("Invalid direction");
                }
                if (exitTeleport) {
                    write(game.getTeleportRoomName());
                    write(game.getTeleportRoomDescription());
                }
                playerHasMoved = true;
                break;
            case "back":
                if (game.getCombatTargetID() != -1) {
                    write("You've received " + game.npcAttack() + " from " + game.getCombatTarget().getName());
                }
                game.back();
                playerHasMoved = true;
                break;
            case "talk":
                write(game.talk(getFirstArgument(command)));
                break;
            case "take":
                game.take(getFirstArgument(command));
                write("A " + getFirstArgument(command) + " has been added to your inventory");
                graphicsFacade.takeItem(getFirstArgument(command));
                break;
            case "equip":
                game.equip(getFirstArgument(command));
                write("The " + getFirstArgument(command) + " has been equipped");
                graphicsFacade.equipItem(getFirstArgument(command));
                break;
            case "drop":
                game.dropItem(getFirstArgument(command));
                write("You dropped " + getFirstArgument(command));
                graphicsFacade.dropItem(getFirstArgument(command));
                break;
            case "give":
                write(game.give(getFirstArgument(command), getSecondArgument(command)));
                write("You gave " + getFirstArgument(command) + " to " + getSecondArgument(command));
                graphicsFacade.giveItem(getFirstArgument(command));
                break;
            case "use":
                int tempHp = game.use(getFirstArgument(command));
                write(game.getItemDescription(getFirstArgument(command)));
                if (tempHp > 0) {
                    write("You've gained " + tempHp + " hps");
                } else if (tempHp < 0) {
                    write("You've lost " + (-tempHp) + " hps");
                }
                graphicsFacade.useItem(getFirstArgument(command));
                break;
            case "help":
                write("Commands: ");
                write(printCommands(alwaysAllowedCommands));
                write(printCommands(genericCommands));
                if (game.getCombatTargetID() != -1)
                    write(printCommands(combatCommands));
                break;
            case "save":
                if (!s3Handler.isOffline()) {
                    write(Saver.saveGame(game, saveName, s3Handler));
                    write("Game saved. " + saveName + " has been saved");
                } else {
                    write("Not available in offline mode");
                }
                break;
            default:
                write("This command does not exist");

        }
    }

    private String getFirstArgument(ArrayList<String> command) throws Exception {
        String s = "";
        if (command.size() == 1) throw new Exception("No first argument");
        for (int i = 1; i < command.size() && !(command.get(i).equals("to")); i++) {
            s += command.get(i) + " ";
        }
        return s.trim();
    }

    private String getSecondArgument(ArrayList<String> command) throws Exception {
        String s = "";
        int i = 1;
        while (i < command.size() && !command.get(i).equals("to")) i++;
        if (i == command.size())
            throw new Exception("No second argument");
        i++;
        while (i < command.size()) {
            s += command.get(i) + " ";
            i++;
        }
        return s.trim();
    }


}
