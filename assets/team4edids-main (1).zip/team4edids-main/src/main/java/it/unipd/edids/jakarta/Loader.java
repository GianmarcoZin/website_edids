package it.unipd.edids.jakarta;


import it.unipd.edids.*;
import it.unipd.edids.amazon.AWSS3Handler;
import it.unipd.edids.entities.Entity;
import it.unipd.edids.entities.Monster;
import it.unipd.edids.entities.Trader;
import it.unipd.edids.items.*;
import it.unipd.edids.jakarta.wrappers.*;
import it.unipd.edids.utilities.ItemPair;
import it.unipd.edids.utilities.Paths;
import it.unipd.edids.utilities.TraderState;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Class for loading the game save from an XML file
 */
public class Loader {
    private static final String TELEPORT_ROOM_NAME = "Tunnels Room";
    private static final String BOSS_ROOM_NAME = "Final Boss Room";
    private static final int MUMMY_ID = 9;

    /**
     * Method for getting the Document object from an XML file
     *
     * @param inputFile file InputStream
     * @return Document object or null if an exception is thrown
     */
    private static Document getDocumentObj(InputStream inputFile) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance(); // create a new instance of a DocumentBuilderFactory
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder(); // create a new instance of a DocumentBuilder
            Document doc = dBuilder.parse(inputFile); // parse the content of the given file as an XML document

            return doc;  // get the elements by tag name
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Method for deserializing an XML file
     *
     * @param cls      Class type to deserialize into
     * @param filename Name of the file to deserialize
     * @param <T>      Generic type passed in input
     * @return The proper class after reading the input file or null if an exception is thrown
     */
    public static <T> T deserialize(Class<T> cls, String filename) {
        try {
            ClassLoader classLoader = ClassLoader.getSystemClassLoader(); // get the class loader
            JAXBContext jaxbContext = JAXBContext.newInstance(cls); // create a new instance of a JAXBContext
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller(); // create a new instance of Unmarshaller
            T obj = cls.cast(jaxbUnmarshaller.unmarshal(classLoader.getResourceAsStream(filename))); // unmarshal the input file

            return obj;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Method for getting the items from the XML files
     *
     * @return ArrayList of items
     */
    public static ArrayList<Item> getItems() {
        ArrayList<Item> items = new ArrayList<>();

        try {
            // create the lists of items calling the deserialize method
            ArrayList<ConsumableItem> consumableItems = (ArrayList<ConsumableItem>) deserialize(ConsumableItemList.class, Paths.PATH_CONSUMABLE_ITEMS).getConsumableItemList();
            ArrayList<NonPickableItem> nonPickableItems = (ArrayList<NonPickableItem>) deserialize(NonPickableItemList.class, Paths.PATH_NON_PICKABLE_ITEMS).getNonPickableItemList();
            ArrayList<PickableItem> pickableItems = (ArrayList<PickableItem>) deserialize(PickableItemList.class, Paths.PATH_PICKABLE_ITEMS).getPickableItemList();
            ArrayList<WeaponItem> weaponItems = (ArrayList<WeaponItem>) deserialize(WeaponItemList.class, Paths.PATH_WEAPON_ITEMS).getWeaponItemList();

            // add all the items to the items list
            items.addAll(consumableItems);
            items.addAll(pickableItems);
            items.addAll(nonPickableItems);
            items.addAll(weaponItems);
            items.sort(null); // sort the items list to be sure the items are in order

            if (!checkItemValidity(items)) throw new Exception("Non-contiguous item IDs found in items list.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }

        return items;
    }

    /**
     * Method for getting the entities from the XML files
     *
     * @return ArrayList of entities
     */
    public static ArrayList<Entity> getEntities() {
        ArrayList<Entity> entities = new ArrayList<>(); // create a new ArrayList of entities

        try {
            // filling the arraylist with the entities calling the deserialize method
            entities.addAll(deserialize(TraderList.class, Paths.PATH_TRADERS).getTraderList());
            entities.addAll(deserialize(MonsterList.class, Paths.PATH_MONSTERS).getMonsterList());
            entities.sort(null); // sort the entities list to be sure the entities are in order

            if (!checkEntityValidity(entities)) throw new Exception("Non-contiguous item IDs found in items list.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }

        return entities;
    }

    /**
     * Method for getting the rooms from the XML file
     *
     * @return ArrayList of rooms
     */
    private static ArrayList<Room> getRooms() {
        try {
            ArrayList<Room> rooms = (ArrayList<Room>) deserialize(RoomList.class, Paths.PATH_ROOMS).getRoomList();
            rooms.sort(null);
            return rooms;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    /**
     * Returns a Map object with the rooms loaded from the XML file
     *
     * @return Map object
     */
    public static Map loadMap() {
        ArrayList<Room> roomList = getRooms();

        Map gameMap = new Map(roomList);

        for (Room room : roomList) {
            switch (room.getName()) {
                case TELEPORT_ROOM_NAME:
                    gameMap.setTeleportRoomID(room.getId());
                    break;
                case BOSS_ROOM_NAME:
                    gameMap.setBossRoomID(room.getId());
                    break;
            }
        }
        return gameMap;
    }

    /**
     * Method that creates the Game object from the save file
     *
     * @param saveFile  the name of the save file
     * @param s3handler the s3 handler for retrieving the save file
     * @return the Game object created
     */
    public static Game loadSave(String saveFile, AWSS3Handler s3handler) {
        try {
            Map gameMap = loadMap();
            Player player = new Player();

            // class loader called to get the resources correctly
            ClassLoader classLoader = ClassLoader.getSystemClassLoader();

            Document saveDoc;
            // if the save file is the new game save, the file is loaded from the resources
            // else is downloaded from the s3 bucket
            if (saveFile.equals(Paths.PATH_NEW_GAME_SAVE)) {
                saveDoc = getDocumentObj(Objects.requireNonNull(classLoader.getResource(saveFile).openStream()));
            } else {
                saveDoc = getDocumentObj(new FileInputStream(s3handler.donwloadObject(saveFile)));
            }

            Node rooms = null;
            Node playerInfo = null;

            // retrieve the rooms and player info from the save file and puts it in node structures
            Node saveNode = saveDoc.getChildNodes().item(getNodeId(saveDoc, "save"));
            for (int i = 0; i < saveNode.getChildNodes().getLength(); i++) {
                if (saveNode.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE) {
                    if (saveNode.getChildNodes().item(i).getNodeName().equals("rooms")) {
                        rooms = saveNode.getChildNodes().item(i);
                    } else if (saveNode.getChildNodes().item(i).getNodeName().equals("player")) {
                        playerInfo = saveNode.getChildNodes().item(i);
                    }
                }
            }

            // get player position
            int playerPosition = Integer.parseInt(playerInfo.getChildNodes().item(getNodeId(playerInfo, "playerPosition")).getTextContent());
            // get all rooms data
            getRoomsData(gameMap, rooms);
            // get items
            ArrayList<Item> items = getItems();
            // get player data
            player = getPlayerData(playerInfo);
            int weight = 0;
            // update player inventory weight
            for (ItemPair p : player.getInventory()) {
                if (items.get(p.getId()) instanceof PickableItem) {
                    weight += ((PickableItem) items.get(p.getId())).getWeight();
                }
            }
            player.setInventoryWeight(weight);

            // find and place the mummy in the map
            int mummyPosition = -1;
            for (int i = 0; i < gameMap.getGameMap().size(); i++) {
                for (int j = 0; j < gameMap.getRoom(i).getEntities().size(); j++) {
                    if (gameMap.getRoom(i).getEntities().get(j).getId() == MUMMY_ID) {
                        mummyPosition = gameMap.getRoom(i).getId();
                    }
                }
            }

            return new Game(gameMap, items, player, playerPosition, mummyPosition);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method for getting the player object given an XML node
     *
     * @param playerInfo the node containing the player info
     * @return the Player object created
     */
    private static Player getPlayerData(Node playerInfo) {
        // hp
        int hp = Integer.parseInt(playerInfo.getChildNodes().item(getNodeId(playerInfo, "hp")).getTextContent());
        // score
        int score = Integer.parseInt(playerInfo.getChildNodes().item(getNodeId(playerInfo, "score")).getTextContent());
        // equippedWeaponID
        int equippedWeaponID = Integer.parseInt(playerInfo.getChildNodes().item(getNodeId(playerInfo, "equippedWeaponID")).getTextContent());
        // bossesDefeated
        int bossesDefeated = Integer.parseInt(playerInfo.getChildNodes().item(getNodeId(playerInfo, "bossesDefeated")).getTextContent());
        // inventory
        Node inventory = playerInfo.getChildNodes().item(getNodeId(playerInfo, "inventory"));
        // effectList
        Node effects = playerInfo.getChildNodes().item(getNodeId(playerInfo, "effects"));

        ArrayList<ItemPair> inventoryList = getItemPairs(inventory);
        ArrayList<Integer> effectList = getEffects(effects);

        return new Player(inventoryList, hp, equippedWeaponID, score, bossesDefeated, effectList);
    }

    /**
     * Method for filling the game map with rooms
     *
     * @param gameMap the game map to fill
     * @param rooms   the node containing the rooms info
     */
    private static void getRoomsData(Map gameMap, Node rooms) {
        // room
        for (int i = 0; i < rooms.getChildNodes().getLength(); i++) {
            if (rooms.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE) {
                // id
                int id = Integer.parseInt(rooms.getChildNodes().item(i).getChildNodes().item(getNodeId(rooms.getChildNodes().item(i), "id")).getTextContent());
                // isDiscovered
                boolean isDiscovered = Boolean.parseBoolean(rooms.getChildNodes().item(i).getChildNodes().item(getNodeId(rooms.getChildNodes().item(i), "isDiscovered")).getTextContent());
                // items
                Node itemsNode = rooms.getChildNodes().item(i).getChildNodes().item(getNodeId(rooms.getChildNodes().item(i), "items"));
                // entities
                Node entitiesNode = rooms.getChildNodes().item(i).getChildNodes().item(getNodeId(rooms.getChildNodes().item(i), "entities"));

                gameMap.getRoom(id).setDiscovered(isDiscovered);
                gameMap.getRoom(id).setItems(getItemPairs(itemsNode));
                gameMap.getRoom(id).setEntities(getEntityList(entitiesNode, getEntities()));
            }
        }
    }

    /**
     * Method for getting the node id
     *
     * @param node the node to get the id from
     * @param name the name of the node
     * @return the id of the node
     */
    private static int getNodeId(Node node, String name) {
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            if (node.getChildNodes().item(i).getNodeName().equals(name)) return i;
        }
        return -1;
    }

    /**
     * Method for getting the item pairs from a node
     *
     * @param itemList the node containing the item pairs
     * @return the ArrayList of ItemPair objects
     */
    private static ArrayList<ItemPair> getItemPairs(Node itemList) {
        ArrayList<ItemPair> itemPairs = new ArrayList<>();

        for (int i = 0; i < itemList.getChildNodes().getLength(); i++) {
            getNodeId(itemList.getChildNodes().item(i), "id");
            if (itemList.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE && itemList.getChildNodes().item(i).getChildNodes().item(getNodeId(itemList.getChildNodes().item(i), "id")) != null) {
                int id = Integer.parseInt(itemList.getChildNodes().item(i).getChildNodes().item(getNodeId(itemList.getChildNodes().item(i), "id")).getTextContent());
                int quantity = Integer.parseInt(itemList.getChildNodes().item(i).getChildNodes().item(getNodeId(itemList.getChildNodes().item(i), "quantity")).getTextContent());
                ItemPair itemPair = new ItemPair(id, quantity);
                itemPairs.add(itemPair);
            }
        }

        return itemPairs;
    }

    /**
     * Method for getting the effects from a node
     *
     * @param effectList the node containing the effects
     * @return the ArrayList of effects
     */
    private static ArrayList<Integer> getEffects(Node effectList) {
        ArrayList<Integer> effects = new ArrayList<>();

        for (int i = 0; i < effectList.getChildNodes().getLength(); i++) {
            if (effectList.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE) {
                effects.add(Integer.parseInt(effectList.getChildNodes().item(i).getTextContent()));
            }
        }

        return effects;
    }

    /**
     * Method for getting the entities from a node
     *
     * @param node       the node containing the entities
     * @param entityList the list of entities
     * @return the ArrayList of entities
     */
    public static ArrayList<Entity> getEntityList(Node node, ArrayList<Entity> entityList) {
        ArrayList<Entity> entities = new ArrayList<>();

        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            if (node.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE && node.getChildNodes().item(i).getChildNodes().item(getNodeId(node.getChildNodes().item(i), "id")) != null) {
                // id
                int id = Integer.parseInt(node.getChildNodes().item(i).getChildNodes().item(getNodeId(node.getChildNodes().item(i), "id")).getTextContent());
                // hp o state
                if (entityList.get(id) instanceof Trader) {
                    int genericAttribute = Integer.parseInt(node.getChildNodes().item(i).getChildNodes().item(getNodeId(node.getChildNodes().item(i), "state")).getTextContent());
                    ((Trader) entityList.get(id)).setState(TraderState.values()[genericAttribute]);
                } else if (entityList.get(id) instanceof Monster) {
                    int genericAttribute = Integer.parseInt(node.getChildNodes().item(i).getChildNodes().item(getNodeId(node.getChildNodes().item(i), "hp")).getTextContent());
                    ((Monster) entityList.get(id)).setHp(genericAttribute);
                }
                entities.add(entityList.get(id));
            }
        }

        return entities;
    }

    /**
     * Support method to check if the item are ordered correctly
     *
     * @param items the list of items
     * @return true if the items are ordered correctly, false otherwise
     */
    private static boolean checkItemValidity(ArrayList<Item> items) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getId() != i) return false;
        }

        return true;
    }

    /**
     * Support method to check if the entities are ordered correctly
     *
     * @param entities the list of entities
     * @return true if the entities are ordered correctly, false otherwise
     */
    private static boolean checkEntityValidity(ArrayList<Entity> entities) {
        for (int i = 0; i < entities.size(); i++) {
            if (entities.get(i).getId() != i) return false;
        }

        return true;
    }
}























