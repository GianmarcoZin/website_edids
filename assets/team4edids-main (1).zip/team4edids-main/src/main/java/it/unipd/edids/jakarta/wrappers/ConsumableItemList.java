package it.unipd.edids.jakarta.wrappers;

import it.unipd.edids.items.ConsumableItem;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

/**
 * Wrapper utility class for the list of consumable items
 */
@XmlRootElement(name = "consumableItems")
@XmlAccessorType(XmlAccessType.FIELD)
public class ConsumableItemList {
    @XmlElement(name = "consumableItem")
    private List<ConsumableItem> consumableItemList;

    /**
     * Default constructor for the ConsumableItemList class
     */
    public ConsumableItemList() {
    }

    /**
     * Constructor for the ConsumableItemList class
     *
     * @param consumableItemList list of consumable items
     */
    public ConsumableItemList(List<ConsumableItem> consumableItemList) {
        this.consumableItemList = consumableItemList;
    }

    /**
     * Getter for the list of consumable items
     *
     * @return list of consumable items
     */
    public List<ConsumableItem> getConsumableItemList() {
        return consumableItemList;
    }

    /**
     * Setter for the list of consumable items
     *
     * @param consumableItemList list of consumable items
     */
    public void setConsumableItemList(List<ConsumableItem> consumableItemList) {
        this.consumableItemList = consumableItemList;
    }
}
