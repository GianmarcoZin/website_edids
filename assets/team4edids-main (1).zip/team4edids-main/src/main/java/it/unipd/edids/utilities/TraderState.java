package it.unipd.edids.utilities;

/**
 * Enumeration class for the trader states
 */
public enum TraderState {
    GREETING,
    WAITING,
    SERVED
}
