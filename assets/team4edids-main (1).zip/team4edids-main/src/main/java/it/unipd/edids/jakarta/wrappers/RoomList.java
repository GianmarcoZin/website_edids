package it.unipd.edids.jakarta.wrappers;

import it.unipd.edids.Room;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

/**
 * Wrapper utility class for the list of rooms
 */
@XmlRootElement(name = "rooms")
@XmlAccessorType(XmlAccessType.FIELD)
public class RoomList {
    @XmlElement(name = "room")
    private List<Room> roomList;

    /**
     * Default constructor for the RoomList class
     */
    public RoomList() {
    }

    /**
     * Constructor for the RoomList class
     *
     * @param roomList list of rooms
     */
    public RoomList(List<Room> roomList) {
        this.roomList = roomList;
    }

    /**
     * Getter for the list of rooms
     *
     * @return list of rooms
     */
    public List<Room> getRoomList() {
        return roomList;
    }

    /**
     * Setter for the list of rooms
     *
     * @param roomList list of rooms
     */
    public void setRoomList(List<Room> roomList) {
        this.roomList = roomList;
    }
}
