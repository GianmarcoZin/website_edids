package it.unipd.edids.jakarta.wrappers;

import it.unipd.edids.items.PickableItem;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

/**
 * Wrapper utility class for the list of pickable items
 */
@XmlRootElement(name = "pickableItems")
@XmlAccessorType(XmlAccessType.FIELD)
public class PickableItemList {
    @XmlElement(name = "pickableItem")
    private List<PickableItem> pickableItemList;

    /**
     * Default constructor for the PickableItemList class
     */
    public PickableItemList() {

    }

    /**
     * Constructor for the PickableItemList class
     *
     * @param pickableItemList list of pickable items
     */
    public PickableItemList(List<PickableItem> pickableItemList) {
        this.pickableItemList = pickableItemList;
    }

    /**
     * Getter for the list of pickable items
     *
     * @return list of pickable items
     */
    public List<PickableItem> getPickableItemList() {
        return pickableItemList;
    }

    /**
     * Setter for the list of pickable items
     *
     * @param pickableItemList list of pickable items
     */
    public void setPickableItemList(List<PickableItem> pickableItemList) {
        this.pickableItemList = pickableItemList;
    }
}

