package it.unipd.edids.graphics;

import javax.swing.*;
import java.awt.*;

public class StatsPanel extends JPanel {
    public static final int X = 25;
    public static final int Y = MapPanel.PANEL_WIDTH + MapPanel.PADDING + 25;
    public static final int WIDTH = MapPanel.PANEL_WIDTH;
    public static final int HEIGHT = 160;
    public static final int BORDER_SIZE = 2;
    public static final int LABEL_PADDING = 12;
    public static final int LABEL_WIDTH = WIDTH - 2 * LABEL_PADDING;
    public static final int LABEL_HEIGHT = 20;
    public static final String INSIDE_COLOR = Frame.ITEM_COLOR;
    public static final String BACKGROUND_COLOR = Frame.BACKGROUND_COLOR;
    public static final String BORDER_COLOR = Frame.BORDER_COLOR;

    private int hp;
    private int score;
    private int bossesDefeated;
    private int inventoryWeight;
    private JLabel[] labels = new JLabel[4];

    public StatsPanel() {
        this.setLayout(null);
        this.hp = 0;
        this.score = 0;
        this.bossesDefeated = 0;
        this.inventoryWeight = 0;
        this.setBounds(X,Y, WIDTH, HEIGHT);
        setBorder(BorderFactory.createMatteBorder(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, Color.decode(BORDER_COLOR)));
        setBackground(Color.decode(INSIDE_COLOR));
        setOpaque(true);

        labels[0] = new JLabel("HP: " + this.hp);
        labels[1] = new JLabel("Score: " + this.score);
        labels[2] = new JLabel("Bosses defeated: " + this.bossesDefeated);
        labels[3] = new JLabel("Inventory weight: " + this.inventoryWeight);
        for (int i = 0; i < 4; i++) {
            labels[i].setBounds(LABEL_PADDING, (i + 1) * LABEL_PADDING + i * LABEL_HEIGHT, LABEL_WIDTH, LABEL_HEIGHT);
            labels[i].setFont(Frame.FONT);
            labels[i].setForeground(Color.decode(BORDER_COLOR));
            add(labels[i]);
        }
    }

    public void setHp(int hp) {
        this.hp = hp;
        labels[0].setText("HP: " + this.hp);
    }

    public void setScore(int score) {
        this.score = score;
        labels[1].setText("Score: " + this.score);
    }

    public void setBossesDefeated(int bossesDefeated) {
        this.bossesDefeated = bossesDefeated;
        labels[2].setText("Bosses defeated: " + this.bossesDefeated);
    }

    public void setInventoryWeight(int inventoryWeight) {
        this.inventoryWeight = inventoryWeight;
        labels[3].setText("Inventory weight: " + this.inventoryWeight);
    }
}
