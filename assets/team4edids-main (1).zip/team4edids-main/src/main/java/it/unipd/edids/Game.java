package it.unipd.edids;

import it.unipd.edids.entities.Entity;
import it.unipd.edids.entities.Monster;
import it.unipd.edids.entities.Trader;
import it.unipd.edids.items.*;
import it.unipd.edids.utilities.Direction;
import it.unipd.edids.utilities.ItemPair;

import java.util.ArrayList;
import java.util.Stack;

public class Game {
    private Map gameMap;
    private ArrayList<Item> items;
    private Player player;
    private int playerPosition;
    private int mummyPosition;
    private int combatTargetID;
    private Stack<Integer> lastPlayerPositions;
    private boolean gameOver;
    private boolean parried;
    private static final double PARRY_CHANCE = 0.5;
    private static final double ATTACK_GAIN = 1.3;
    private boolean bonusDamage;

    public Game(Map gameMap, ArrayList<Item> items, Player player, int playerPosition, int mummyPosition) {
        this.gameMap = gameMap;
        this.items = items;
        this.player = player;
        this.playerPosition = playerPosition;
        this.mummyPosition = mummyPosition;
        this.combatTargetID = -1;
        lastPlayerPositions = new Stack<Integer>();
        parried = false;
        gameOver = false;
        this.bonusDamage = false;
    }

    public boolean move(Direction direction) throws Exception {
        if (gameMap.getRoom(playerPosition).getPassage(direction) == -1)
            throw new Exception("There's a wall there...");
        if (gameMap.getRoom(playerPosition).getPassage(direction) == gameMap.getBossRoomID() && player.getBossesDefeated() < 3)
            throw new Exception("You must defeat all the other bosses first");

        boolean inTeleport = false;

        lastPlayerPositions.add(playerPosition);
        playerPosition = gameMap.getRoom(playerPosition).getPassage(direction);
        if (gameMap.getRoom(playerPosition).getId() == gameMap.getTeleportRoomID()) {
            gameMap.getRoom(gameMap.getTeleportRoomID()).setDiscovered(true);
            playerPosition = getRandomRoom();
            lastPlayerPositions.clear();
            inTeleport = true;
        }
        combatTargetID = -1;

        // the mummy moves every time the player moves
        updateMummyPosition();

        gameMap.getRoom(playerPosition).setDiscovered(true);

        return inTeleport;
    }

    private int getRandomRoom() {
        int rand = (int) (Math.random() * 10) % gameMap.getSize();
        while (rand == gameMap.getBossRoomID() || rand == gameMap.getTeleportRoomID())
            rand = (int) ((Math.random() * 10) % gameMap.getSize());
        return rand;
    }


    public void back() throws Exception {
        if (lastPlayerPositions.isEmpty())
            throw new Exception("Cannot move back");
        combatTargetID = -1;
        playerPosition = lastPlayerPositions.pop();
    }

    public int use(int itemID) throws Exception {
        int tempHp;
        if (items.get(itemID) instanceof ConsumableItem) {
            tempHp = player.use((ConsumableItem) items.get(itemID));
        } else if (items.get(itemID) instanceof NonPickableItem) {
            tempHp = player.use((NonPickableItem) items.get(itemID));
        } else {
            throw new Exception("Item not usable");
        }
        if (player.getHP() <= 0) {
            gameOver = true;
        }
        return tempHp;
    }

    public int use(String nameItem) throws Exception {
        return use(getItemID(nameItem));
    }

    public String getItemDescription(String itemName) {
        return items.get(findItem(itemName)).getDescription();
    }

    public String look() {
        return "Items:<br>" + getRoomInventory() + "Entities:<br>" + getRoomEntities();
    }

    public void take(int itemID) throws Exception {
        if (!(items.get(itemID) instanceof PickableItem))
            throw new Exception("Item not pickable");
        ArrayList<ItemPair> roomItems = gameMap.getRoom(playerPosition).getItems();
        int ind = roomItems.indexOf(new ItemPair(itemID, 0));
        if (ind == -1)
            throw new Exception("Item not available");

        if (((PickableItem) items.get(itemID)).getWeight() + player.getInventoryWeight() > player.MAX_WEIGHT) {
            throw new Exception("Item too heavy");
        }
        player.add(roomItems.remove(ind), ((PickableItem) items.get(itemID)).getWeight());
    }

    public void take(String itemName) throws Exception {
        take(getItemID(itemName));
    }

    public void equip(int itemID) throws Exception {
        if (!(items.get(itemID) instanceof WeaponItem))
            throw new Exception("Item not equippable");
        player.setEquippedWeaponID(itemID);
    }

    public void equip(String itemName) throws Exception {
        equip(getItemID(itemName));
    }

    public int getItemID(String name) throws Exception {
        int id = findItem(name);
        if (id == -1)
            throw new Exception("Invalid item name");
        else
            return id;
    }

    public int getEntityID(String name) throws Exception {
        int id = -1;
        for (int i = 0; i < gameMap.getRoom(playerPosition).getEntities().size(); i++) {
            if (gameMap.getRoom(playerPosition).getEntities().get(i).getName().equalsIgnoreCase(name)) {
                id = gameMap.getRoom(playerPosition).getEntities().get(i).getId();
            }
        }

        if (id == -1) {
            throw new Exception("Entity not found in current room");
        } else {
            return id;
        }
    }

    public String give(int itemID, int traderID) throws Exception {
        String s = "";
        int traderIndex = gameMap.getRoom(playerPosition).getEntities().indexOf(new Trader(traderID, ""));
        if (traderIndex != -1 && player.hasItem(itemID) && gameMap.getRoom(playerPosition).getEntities().get(traderIndex) instanceof Trader) {
            int itemIndex = player.getInventory().indexOf(new ItemPair(itemID, 0));
            Trader trader = (Trader) (gameMap.getRoom(playerPosition).getEntities().get(traderIndex));
            int dropID = trader.acceptItem(player.getInventory().get(itemIndex).getId());

            if (dropID > 0) {
                s += trader.getName() + ": " + trader.getMessages().getGoodItemMsg() + "<br>";

                player.drop(itemID, ((PickableItem) items.get(itemID)).getWeight());
                player.add(new ItemPair(dropID, 1), ((PickableItem) items.get(dropID)).getWeight());
                player.setScore(player.getScore() + 20);
                s += items.get(dropID).getName() + " added to your inventory<br>";
            } else {
                System.out.println(trader.getName() + ": " + trader.getMessages().getBadItemMsg());
                throw new Exception("Invalid item given");
            }
        } else throw new Exception("Invalid item given or trader not present");
        return s;
    }

    public String give(String itemName, String traderName) throws Exception {
        return give(getItemID(itemName), getEntityID(traderName));
    }

    public String talk(int traderID) throws Exception {
        int indexTrader = gameMap.getRoom(playerPosition).getEntities().indexOf(new Trader(traderID, ""));

        if (indexTrader != -1 && gameMap.getRoom(playerPosition).getEntities().get(indexTrader) instanceof Trader) {
            Trader trader = ((Trader) gameMap.getRoom(playerPosition).getEntities().get(indexTrader));

            return trader.talk();
        } else {
            throw new Exception("Invalid trader ID");
        }
    }

    public String talk(String traderName) throws Exception {
        return talk(getEntityID(traderName));
    }

    public String attack() throws Exception {
        if (combatTargetID == -1)
            throw new Exception("No attack target");

        String s = "";
        int damage;
        int inflictedDamage;
        if (player.getEquippedID() == -1)
            damage = 0;
        else
            damage = ((WeaponItem) items.get(player.getEquippedID())).getDamage();

        int indexMonster = gameMap.getRoom(playerPosition).getEntities().indexOf(new Monster(combatTargetID, "", 0, 0, 0,0, -1));
        Monster monster = ((Monster) gameMap.getRoom(playerPosition).getEntities().get(indexMonster));

        if (player.getEffectList().contains(monster.getEffectId()) || monster.getEffectId() == -1) {
            if (bonusDamage) {
                inflictedDamage = (int) (damage * ATTACK_GAIN);
                monster.setHp(monster.getHp() - inflictedDamage);
                bonusDamage = false;
                s += "You've inflicted extra " + ((int) ((ATTACK_GAIN - 1) * 100)) + "% damage after the parry! Total damage inflicted to " + monster.getName() + ": " + inflictedDamage + "<br>";
            } else {
                inflictedDamage = damage;
                s += "You've inflicted " + inflictedDamage + " damage to " + monster.getName() + "<br>";
            }

            monster.setHp(monster.getHp() - inflictedDamage);
            if (monster.getHp() <= 0) {
                if (monster.getIsBoss()) player.incrementBossesDefeated();
                player.setScore(player.getScore() + 10);
                s += monster.getName() + " dropped " + items.get(monster.getDropID()).getName() + "<br>";
                s += "You've defeated " + getCombatTarget().getName() + "<br>";
                gameMap.getRoom(playerPosition).addItem(monster.dropItem());
                gameMap.getRoom(playerPosition).getEntities().removeLast();
                setCombatTargetID(-1);
                if (player.getBossesDefeated() == 4) gameOver = true;
            }

            // if (gameMap.getRoom(playerPosition).getEntities().getLast() instanceof Monster)
            //   setCombatTargetID(gameMap.getRoom(playerPosition).getEntities().getLast().getId());


        } else {
            s += "You cannot attack " + monster.getName() + " because you don't have the right effect.<br>";
        }
        return s;
    }


    public boolean parry() throws Exception {
        if (combatTargetID == -1)
            throw new Exception("Cannot parry. No enemies in the room");
        if (Math.random() > PARRY_CHANCE) {
            parried = true;
            return true;
        } else {
            parried = false;
            return false;
        }
    }

    public int npcAttack() {
        if (!parried) {
            int indTarget = gameMap.getRoom(playerPosition).getEntities().indexOf(new Monster(combatTargetID, "", 0, 0, 0,0, -1));
            int damage = ((Monster) gameMap.getRoom(playerPosition).getEntities().get(indTarget)).getDamage();

            if (player.getHP() - damage <= 0) gameOver = true;
            player.setHP(player.getHP() - damage);
            bonusDamage = false;
            return damage;
        } else {
            parried = false;
            bonusDamage = true;
            return 0;
        }
    }

    public void updateMummyPosition() {
        int randDirection = (int) (Math.random() * 10) % 4;
        while (gameMap.getRoom(mummyPosition).getPassages()[randDirection] == -1)
            randDirection = (randDirection + 1) % 4;
        int oldMummyPosition = mummyPosition;
        mummyPosition = gameMap.getRoom(mummyPosition).getPassages()[randDirection];
        gameMap.getRoom(mummyPosition).getEntities().add(gameMap.getRoom(oldMummyPosition).getEntities().removeLast());
    }

    public boolean startCombat() {

        if (gameMap.getRoom(playerPosition).getEntities().isEmpty()) {
            setCombatTargetID(-1);
            return false;
        } else if (gameMap.getRoom(playerPosition).getEntities().getLast() instanceof Monster) {
            setCombatTargetID(gameMap.getRoom(playerPosition).getEntities().getLast().getId());
            return true;
        } else {
            setCombatTargetID(-1);
        }
        return false;
    }

    private void dropItem(int itemID) throws Exception {
        if (!(player.hasItem(itemID)))
            throw new Exception("Item not droppable");

        gameMap.getRoom(playerPosition).addItem(itemID);
        player.drop(itemID, ((PickableItem) items.get(itemID)).getWeight());
    }

    public void dropItem(String itemName) throws Exception {
        dropItem(getItemID(itemName));
    }

    public String gameOver() {
        return "GAME OVER!<br>" + "Score: " + player.getScore() + "<br>Bosses defeated: " + player.getBossesDefeated();
    }

    public String win() {
        return "YOU WON!<br>" + "Score " + player.getScore() + "<br>Bosses defeated: " + player.getBossesDefeated();
    }


    // ritorna l'id dell'item in items con nome == name
    private int findItem(String name) {
        for (int i = 0; i < items.size(); i++) {
            if (name.equalsIgnoreCase(items.get(i).getName()))
                return i;
        }
        return -1;
    }

    // ritorna l'indice dell'elemento con id == key in arr
    private static int findItem(ArrayList<ItemPair> arr, int key) {
        for (int i = 0; i < arr.size(); i++) {
            if (key == arr.get(i).getId())
                return i;
        }
        return -1;
    }

    public String getPlayerInventory() {
        String s = "";
        ArrayList<ItemPair> inventory = player.getInventory();

        if (inventory.isEmpty()) return "Inventory is empty";

        // TODO nella grafica mostrare che gli item sono usabili in qualche modo
        s += "Inventory weight: " + player.getInventoryWeight() + "/" + player.MAX_WEIGHT + "<br>";
        for (int i = 0; i < inventory.size(); i++) {
            s += "- " + items.get(inventory.get(i).getId()).getName() + " x" + inventory.get(i).getQuantity() + " " + ((PickableItem) items.get(inventory.get(i).getId())).getWeight() + "kg";
            if (inventory.get(i).getId() == player.getEquippedID()) s += " (equipped)";
            s += "<br>";
        }
        return s;
    }

    public String getRoomInventory() {
        String s = "";
        ArrayList<ItemPair> inventory = gameMap.getRoom(playerPosition).getItems();

        if (inventory.isEmpty()) return "The room is empty<br>";

        for (int i = 0; i < inventory.size(); i++) {
            s += "- " + items.get(inventory.get(i).getId()).getName() + " x" + inventory.get(i).getQuantity() + "<br>";
        }
        return s;
    }

    public String getRoomEntities() {
        String s = "";
        ArrayList<Entity> entities = gameMap.getRoom(playerPosition).getEntities();

        if (entities.isEmpty()) return "There is no one here.<br>";

        for (int i = 0; i < entities.size(); i++) {
            s += "- " + entities.get(i).getName() + "<br>";
        }

        return s;
    }

    public void setCombatTargetID(int combatTargetID) {
        this.combatTargetID = combatTargetID;
    }

    public int getCombatTargetID() {
        return combatTargetID;
    }

    public String getCurrentRoomDescription() {
        return gameMap.getRoom(playerPosition).getDescription();
    }

    public String getCurrentRoomName() {
        return gameMap.getRoom(playerPosition).getName();
    }

    public Monster getCombatTarget() {
        if (combatTargetID == -1)
            return null;
        else
            return (Monster) gameMap.getRoom(playerPosition).getEntities().getLast();
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public boolean isCombat() {
        return combatTargetID != -1;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public String getPlayerStats() {
        return "HP: " + player.getHP() + "<br>Score: " + player.getScore() + "<br>Bosses defeated: " + player.getBossesDefeated() + "<br>Equipped weapon: " + (player.getEquippedID() != -1 ? items.get(player.getEquippedID()).getName() : "none");
    }

    public int getPlayerPosition() {
        return playerPosition;
    }

    public Map getGameMap() {
        return gameMap;
    }

    public Player getPlayer() {
        return player;
    }

    public String getTeleportRoomName() {
        return gameMap.getRoom(gameMap.getTeleportRoomID()).getName();
    }

    public String getTeleportRoomDescription() {
        return gameMap.getRoom(gameMap.getTeleportRoomID()).getDescription();
    }

    @Override
    public String toString() {
        return "Game{" +
                "gameMap=" + gameMap +
                ", items=" + items +
                ", player=" + player +
                ", playerPosition=" + playerPosition +
                '}';
    }
}
